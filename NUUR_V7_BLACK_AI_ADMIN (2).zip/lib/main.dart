import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;

// ═══════════════════════ KONSTANTA & TEMA ═══════════════════════
const kBg = Color(0xFF000000);
const kBar = Color(0xFF121212);
const kCard = Color(0xFF1C1C1E);
const kHint = Color(0xFF8E8E93);
const kBlue = Color(0xFF0A84FF);
const kLine = Color(0xFF2C2C2E);
const kRed = Color(0xFFFF453A);
const kAdminEmail = 'admin@nuur.com';
const kAiName = 'NUUR COMMUNICATION AI';
const kDbUrl = 'https://voxa-clone-bfbbe-default-rtdb.firebaseio.com';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.black,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: 'AIzaSyBQknHE3NYAOu25YeVbur6e9Qwx8sGWn20',
        appId: '1:996283996536:android:700c0c32f880ae6647108d',
        messagingSenderId: '996283996536',
        projectId: 'voxa-clone-bfbbe',
        databaseURL: kDbUrl,
        storageBucket: 'voxa-clone-bfbbe.firebasestorage.app',
      ),
    );
  } catch (e) {
    if (Firebase.apps.isEmpty) rethrow;
  }
  runApp(const NuurApp());
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: false,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: kBg,
      canvasColor: kBg,
      primaryColor: Colors.white,
      colorScheme: const ColorScheme.dark(
        primary: Colors.white,
        secondary: Colors.white,
        surface: kCard,
        onPrimary: Colors.black,
        onSurface: Colors.white,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: kBar,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        iconTheme: IconThemeData(color: Colors.white),
        titleTextStyle: TextStyle(
            color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
      ),
      iconTheme: const IconThemeData(color: Colors.white),
      dividerColor: kLine,
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: kCard,
        hintStyle: const TextStyle(color: kHint),
        labelStyle: const TextStyle(color: kHint),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      ),
      textSelectionTheme: const TextSelectionThemeData(
        cursorColor: Colors.white,
        selectionColor: Color(0x55FFFFFF),
        selectionHandleColor: Colors.white,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.all(Colors.white),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? const Color(0xFF636366)
                : const Color(0xFF2C2C2E)),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      ),
      progressIndicatorTheme:
          const ProgressIndicatorThemeData(color: Colors.white),
      bottomSheetTheme: const BottomSheetThemeData(
          backgroundColor: kCard, modalBackgroundColor: kCard),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Colors.white, foregroundColor: Colors.black),
      listTileTheme: const ListTileThemeData(
          iconColor: Colors.white, textColor: Colors.white),
      textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: Colors.white)),
    );

// ═══════════════════════ HELPER ═══════════════════════
FirebaseDatabase get db =>
    FirebaseDatabase.instanceFor(app: Firebase.app(), databaseURL: kDbUrl);
String get myUid => FirebaseAuth.instance.currentUser!.uid;
String get myEmail =>
    (FirebaseAuth.instance.currentUser?.email ?? '').toLowerCase();
bool get isAdminUser => myEmail == kAdminEmail;

Map<String, dynamic> asMap(Object? v) =>
    v is Map ? v.map((k, e) => MapEntry(k.toString(), e)) : <String, dynamic>{};

List<Map<String, dynamic>> mapValues(Object? v) =>
    asMap(v).values.map(asMap).toList();

String str(Object? v) => v?.toString() ?? '';
int tsOf(Map m) => m['ts'] is num ? (m['ts'] as num).toInt() : 0;

String hhmm(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts);
  return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

String mmss(int sec) =>
    '${(sec ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}';

void toast(BuildContext c, String m) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      backgroundColor: Colors.white,
      behavior: SnackBarBehavior.floating,
      content: Text(m,
          style: const TextStyle(
              color: Colors.black, fontWeight: FontWeight.w600)),
    ));
}

String bust(String url) {
  final v = DateTime.now().millisecondsSinceEpoch;
  return url.contains('?') ? '$url&v=$v' : '$url?v=$v';
}

Future<String> uploadFile(String path, File f, String contentType) async {
  final ref = FirebaseStorage.instance.ref(path);
  await ref.putFile(f, SettableMetadata(contentType: contentType));
  return bust(await ref.getDownloadURL());
}

final ImagePicker _picker = ImagePicker();

Future<File?> pickImageFile(
    {ImageSource src = ImageSource.gallery, double size = 1280}) async {
  final x = await _picker.pickImage(
      source: src, maxWidth: size, maxHeight: size, imageQuality: 85);
  return x == null ? null : File(x.path);
}

Future<T?> blurPopup<T>(BuildContext context, WidgetBuilder builder) =>
    showGeneralDialog<T>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'tutup',
      barrierColor: Colors.black45,
      transitionDuration: const Duration(milliseconds: 160),
      pageBuilder: (ctx, a, b) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Center(
            child: Material(color: Colors.transparent, child: builder(ctx))),
      ),
      transitionBuilder: (ctx, a, b, child) => FadeTransition(
        opacity: a,
        child: ScaleTransition(
            scale: Tween<double>(begin: 0.92, end: 1.0)
                .animate(CurvedAnimation(parent: a, curve: Curves.easeOut)),
            child: child),
      ),
    );

Widget sheetTile(IconData i, String t, VoidCallback f, {Color? color}) =>
    ListTile(
      leading: Icon(i, color: color ?? Colors.white),
      title: Text(t, style: TextStyle(color: color ?? Colors.white)),
      onTap: f,
    );

// ═══════════════════════ SERVICE NUUR AI ═══════════════════════
class NuurAI {
  static const String baseUrl = 'https://sylvatica.my.id/api/ai/chatgpt';
  static const String apiKey = 'sylva-8e01ad1bb084e62abfe8783b8712194b';
  static const String model = 'NUUR COMMUNICATION AI';

  static String _pick(Object? v) {
    if (v == null) return '';
    if (v is String) return v;
    if (v is Map) {
      for (final k in ['reply', 'result', 'response', 'text', 'message', 'answer']) {
        final r = _pick(v[k]);
        if (r.isNotEmpty) return r;
      }
      return '';
    }
    return v.toString();
  }

  /// GET ...?prompt=...&chat_id=...&auth=nuur_user&apikey=...
  /// return json['reply'] ?? ['result'] ?? ['response'] ?? ['text']
  static Future<String> chat(String prompt, String chatId) async {
    final uri = Uri.parse('$baseUrl?prompt=${Uri.encodeQueryComponent(prompt)}'
        '&chat_id=${Uri.encodeQueryComponent(chatId)}&auth=nuur_user&apikey=$apiKey');
    final res = await http.get(uri).timeout(const Duration(seconds: 90));
    final body = utf8.decode(res.bodyBytes);
    if (res.statusCode != 200) {
      throw Exception('Server AI error (${res.statusCode})');
    }
    Object? j;
    try {
      j = jsonDecode(body);
    } catch (_) {
      j = body;
    }
    String out = '';
    if (j is Map) {
      out = _pick(j['reply'] ?? j['result'] ?? j['response'] ?? j['text']);
    } else {
      out = _pick(j);
    }
    out = out.trim();
    if (out.isEmpty) throw Exception('AI tidak memberi jawaban');
    return out;
  }
}

// ═══════════════════════ WIDGET DASAR ═══════════════════════
/// Listener realtime dengan stream yang di-cache (tidak resubscribe tiap rebuild).
class DbValue extends StatefulWidget {
  final String path;
  final Widget Function(BuildContext context, Object? value, bool loaded) builder;
  const DbValue({super.key, required this.path, required this.builder});
  @override
  State<DbValue> createState() => _DbValueState();
}

class _DbValueState extends State<DbValue> {
  late Stream<DatabaseEvent> _s;
  @override
  void initState() {
    super.initState();
    _s = db.ref(widget.path).onValue;
  }

  @override
  void didUpdateWidget(covariant DbValue old) {
    super.didUpdateWidget(old);
    if (old.path != widget.path) _s = db.ref(widget.path).onValue;
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: _s,
        builder: (c, snap) => widget.builder(
            c, snap.data?.snapshot.value, snap.hasData || snap.hasError),
      );
}

class Avatar extends StatelessWidget {
  final String name;
  final String? url;
  final double r;
  final IconData? icon;
  const Avatar({super.key, this.name = '', this.url, this.r = 26, this.icon});
  @override
  Widget build(BuildContext context) {
    final has = url != null && url!.isNotEmpty;
    return CircleAvatar(
      radius: r,
      backgroundColor: kCard,
      backgroundImage: has ? NetworkImage(url!) : null,
      onBackgroundImageError: has ? (e, st) {} : null,
      child: has
          ? null
          : (icon != null
              ? Icon(icon, color: Colors.white, size: r)
              : Text(name.isEmpty ? '?' : name[0].toUpperCase(),
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: r * .8))),
    );
  }
}

/// Avatar AI: realtime dari /app_config/nuur_ai/photoUrl
class AiAvatar extends StatelessWidget {
  final double r;
  const AiAvatar({super.key, this.r = 20});
  @override
  Widget build(BuildContext context) => DbValue(
        path: 'app_config/nuur_ai/photoUrl',
        builder: (c, v, _) =>
            Avatar(url: str(v), r: r, icon: Icons.smart_toy),
      );
}

class NameRow extends StatelessWidget {
  final String name;
  final bool verified;
  final double icon;
  final TextStyle? style;
  const NameRow(
      {super.key,
      required this.name,
      this.verified = true,
      this.icon = 16,
      this.style});
  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
              child: Text(name, style: style, overflow: TextOverflow.ellipsis)),
          if (verified) ...[
            const SizedBox(width: 4),
            Icon(Icons.verified, color: kBlue, size: icon),
          ],
        ],
      );
}

class PhotoViewPage extends StatelessWidget {
  final String url;
  const PhotoViewPage({super.key, required this.url});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black),
        body: Center(
          child: InteractiveViewer(
            child: Image.network(url,
                fit: BoxFit.contain,
                loadingBuilder: (c, w, p) => p == null
                    ? w
                    : const Center(child: CircularProgressIndicator()),
                errorBuilder: (c, e, s2) =>
                    const Icon(Icons.broken_image, color: kHint, size: 48)),
          ),
        ),
      );
}

class VideoPage extends StatefulWidget {
  final String url;
  const VideoPage({super.key, required this.url});
  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late final VideoPlayerController ctl;
  bool ready = false, error = false;
  @override
  void initState() {
    super.initState();
    ctl = VideoPlayerController.networkUrl(Uri.parse(widget.url));
    ctl.initialize().then((_) {
      if (!mounted) return;
      setState(() => ready = true);
      ctl.play();
    }).catchError((e) {
      if (mounted) setState(() => error = true);
    });
    ctl.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black),
        body: Center(
          child: error
              ? const Text('Video gagal diputar', style: TextStyle(color: kHint))
              : !ready
                  ? const CircularProgressIndicator()
                  : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      AspectRatio(
                          aspectRatio: ctl.value.aspectRatio,
                          child: VideoPlayer(ctl)),
                      VideoProgressIndicator(ctl,
                          allowScrubbing: true,
                          colors: const VideoProgressColors(
                              playedColor: Colors.white,
                              bufferedColor: kLine,
                              backgroundColor: kCard)),
                      IconButton(
                        iconSize: 48,
                        icon: Icon(ctl.value.isPlaying
                            ? Icons.pause_circle_outline
                            : Icons.play_circle_outline),
                        onPressed: () =>
                            ctl.value.isPlaying ? ctl.pause() : ctl.play(),
                      ),
                    ]),
        ),
      );
}

// ═══════════════════════ APP ═══════════════════════
class NuurApp extends StatelessWidget {
  const NuurApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NUUR COMMUNICATION',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: StreamBuilder<User?>(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (c, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                  body: Center(child: CircularProgressIndicator()));
            }
            return snap.data == null ? const AuthPage() : const Gate();
          },
        ),
      );
}

/// Cek profil & status banned sebelum masuk Home.
class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext context) => DbValue(
        path: 'users/$myUid',
        builder: (c, v, loaded) {
          if (!loaded) {
            return const Scaffold(
                body: Center(child: CircularProgressIndicator()));
          }
          final u = asMap(v);
          if (u.isEmpty) return const ProfileBootstrap();
          if (u['isBanned'] == true && !isAdminUser) return const BannedScreen();
          return const HomePage();
        },
      );
}

/// Membuat profil default bila akun ada tapi profil DB belum ada.
class ProfileBootstrap extends StatefulWidget {
  const ProfileBootstrap({super.key});
  @override
  State<ProfileBootstrap> createState() => _ProfileBootstrapState();
}

class _ProfileBootstrapState extends State<ProfileBootstrap> {
  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    await Future.delayed(const Duration(seconds: 2));
    final u = FirebaseAuth.instance.currentUser;
    if (u == null) return;
    try {
      final snap = await db.ref('users/${u.uid}').get();
      if (!snap.exists) {
        final base = (u.email ?? 'user').split('@').first;
        await db.ref('users/${u.uid}').set(
            newProfile(u.uid, u.displayName ?? base, base.toLowerCase(), u.email ?? ''));
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator()));
}

Map<String, Object?> newProfile(
        String uid, String name, String username, String email) =>
    {
      'uid': uid,
      'name': name,
      'username': username,
      'email': email,
      'photoUrl': '',
      'isVerified': true,
      'isBusiness': true,
      'isBanned': false,
      'createdAt': ServerValue.timestamp,
    };

class BannedScreen extends StatelessWidget {
  const BannedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.block, color: Colors.white, size: 84),
                const SizedBox(height: 20),
                const Text('Akun Diblokir',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                const Text(
                    'Akun Anda telah diblokir oleh admin NUUR COMMUNICATION. Hubungi admin jika ini keliru.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: kHint)),
                const SizedBox(height: 28),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12)),
                  onPressed: () => FirebaseAuth.instance.signOut(),
                  child: const Text('Keluar'),
                ),
              ]),
            ),
          ),
        ),
      );
}

// ═══════════════════════ AUTH ═══════════════════════
class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool login = true, busy = false;
  final name = TextEditingController();
  final user = TextEditingController();
  final email = TextEditingController();
  final pass = TextEditingController();

  @override
  void dispose() {
    name.dispose();
    user.dispose();
    email.dispose();
    pass.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    final e = email.text.trim(), p = pass.text;
    final n = name.text.trim();
    final un = user.text.trim().replaceAll('@', '').toLowerCase();
    if (e.isEmpty || p.length < 6 || (!login && (n.isEmpty || un.isEmpty))) {
      toast(context, 'Lengkapi data (password minimal 6 karakter)');
      return;
    }
    setState(() => busy = true);
    try {
      final auth = FirebaseAuth.instance;
      if (login) {
        await auth.signInWithEmailAndPassword(email: e, password: p);
      } else {
        final cred =
            await auth.createUserWithEmailAndPassword(email: e, password: p);
        final u = cred.user!;
        await db.ref('users/${u.uid}').set(newProfile(u.uid, n, un, e));
        await u.updateDisplayName(n);
      }
    } on FirebaseAuthException catch (ex) {
      if (mounted) toast(context, ex.message ?? ex.code);
    } catch (ex) {
      if (mounted) toast(context, '$ex');
    }
    if (mounted) setState(() => busy = false);
  }

  Widget field(TextEditingController c, String hint, IconData icon,
          {bool obscure = false, TextInputType? type}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          obscureText: obscure,
          keyboardType: type,
          autocorrect: false,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
              prefixIcon: Icon(icon, color: kHint), hintText: hint),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                Container(
                  width: 88,
                  height: 88,
                  decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle),
                  child: const Icon(Icons.chat_bubble,
                      color: Colors.black, size: 44),
                ),
                const SizedBox(height: 16),
                const Text('NUUR COMMUNICATION',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                const Text('Business Premium',
                    style: TextStyle(color: kHint, fontWeight: FontWeight.w600)),
                const SizedBox(height: 28),
                if (!login) ...[
                  field(name, 'Nama', Icons.person_outline),
                  field(user, 'Username (@)', Icons.alternate_email),
                ],
                field(email, 'Email', Icons.mail_outline,
                    type: TextInputType.emailAddress),
                field(pass, 'Password', Icons.lock_outline, obscure: true),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12))),
                    onPressed: busy ? null : submit,
                    child: busy
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.black))
                        : Text(login ? 'Masuk' : 'Daftar',
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
                TextButton(
                  onPressed: () => setState(() => login = !login),
                  child: Text(
                      login ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk'),
                ),
              ]),
            ),
          ),
        ),
      );
}

// ═══════════════════════ HOME 5 TAB ═══════════════════════
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  static const _items = <List<Object>>[
    [Icons.chat_bubble_outline, Icons.chat_bubble, 'Chat'],
    [Icons.groups_outlined, Icons.groups, 'Grup'],
    [Icons.campaign_outlined, Icons.campaign, 'Saluran'],
    [Icons.smart_toy_outlined, Icons.smart_toy, 'NUUR AI'],
    [Icons.settings_outlined, Icons.settings, 'Setting'],
  ];

  Widget _navItem(int i) {
    final sel = tab == i;
    final color = sel ? Colors.white : kHint;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => tab = i),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          // indikator tab putih
          AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            height: 2.5,
            width: sel ? 32 : 0,
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 7),
          Icon((sel ? _items[i][1] : _items[i][0]) as IconData,
              color: color, size: 24),
          const SizedBox(height: 3),
          Text(_items[i][2] as String,
              style: TextStyle(
                  color: color,
                  fontSize: 10.5,
                  fontWeight: sel ? FontWeight.w700 : FontWeight.w500)),
          const SizedBox(height: 7),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: tab, children: const [
          ChatTab(),
          GroupsTab(),
          ChannelsTab(),
          NuurAIChatScreen(),
          SettingsTab(),
        ]),
        bottomNavigationBar: Container(
          decoration: const BoxDecoration(
              color: kBar, border: Border(top: BorderSide(color: kLine))),
          child: SafeArea(
            top: false,
            child: Row(children: [for (var i = 0; i < 5; i++) _navItem(i)]),
          ),
        ),
      );
}

// ═══════════════════════ TAB CHAT ═══════════════════════
class ChatTab extends StatefulWidget {
  const ChatTab({super.key});
  @override
  State<ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  String q = '';

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Chat'),
          actions: [
            IconButton(
              tooltip: 'Tambah status',
              icon: const Icon(Icons.add_a_photo_outlined),
              onPressed: () => addStatusSheet(context),
            ),
          ],
        ),
        body: Column(children: [
          const StatusBar(),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: TextField(
              onChanged: (v) => setState(() => q = v.trim().toLowerCase()),
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search, color: kHint),
                  hintText: 'Cari pengguna',
                  contentPadding: EdgeInsets.symmetric(vertical: 8)),
            ),
          ),
          Expanded(
            child: DbValue(
              path: 'users',
              builder: (c, v, loaded) {
                if (!loaded) {
                  return const Center(child: CircularProgressIndicator());
                }
                final list = mapValues(v)
                    .where((u) => str(u['uid']) != myUid && str(u['uid']).isNotEmpty)
                    .where((u) =>
                        q.isEmpty ||
                        str(u['name']).toLowerCase().contains(q) ||
                        str(u['username']).toLowerCase().contains(q))
                    .toList()
                  ..sort((a, b) => str(a['name'])
                      .toLowerCase()
                      .compareTo(str(b['name']).toLowerCase()));
                if (list.isEmpty) {
                  return const Center(
                      child: Text('Belum ada pengguna lain',
                          style: TextStyle(color: kHint)));
                }
                return ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, i) =>
                      const Divider(height: 1, indent: 76),
                  itemBuilder: (c, i) {
                    final u = list[i];
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 4),
                      leading: Avatar(
                          name: str(u['name']), url: str(u['photoUrl'])),
                      title: NameRow(
                          name: str(u['name']),
                          verified: u['isVerified'] == true,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 16)),
                      subtitle: Text('@${str(u['username'])}',
                          style: const TextStyle(color: kHint)),
                      onTap: () => Navigator.push(
                          c,
                          MaterialPageRoute(
                              builder: (_) => ChatPage(peer: u))),
                    );
                  },
                );
              },
            ),
          ),
        ]),
      );
}

class ChatPage extends StatelessWidget {
  final Map<String, dynamic> peer;
  const ChatPage({super.key, required this.peer});
  @override
  Widget build(BuildContext context) {
    final ids = [myUid, str(peer['uid'])]..sort();
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          Avatar(name: str(peer['name']), url: str(peer['photoUrl']), r: 18),
          const SizedBox(width: 10),
          Flexible(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NameRow(
                  name: str(peer['name']),
                  verified: peer['isVerified'] == true,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              Text('@${str(peer['username'])}',
                  style: const TextStyle(fontSize: 12, color: kHint)),
            ]),
          ),
        ]),
      ),
      body: MessageThread(base: 'chats/${ids.join('_')}'),
    );
  }
}

// ═══════════════════════ STATUS 24 JAM ═══════════════════════
Future<void> addStatusSheet(BuildContext context) async {
  showModalBottomSheet(
    context: context,
    builder: (c) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        sheetTile(Icons.photo_outlined, 'Status foto', () {
          Navigator.pop(c);
          _postPhotoStatus(context);
        }),
        sheetTile(Icons.text_fields, 'Status teks', () {
          Navigator.pop(c);
          _postTextStatus(context);
        }),
      ]),
    ),
  );
}

Future<Map<String, Object?>> _statusBase() async {
  final snap = await db.ref('users/$myUid').get();
  final u = asMap(snap.value);
  return {
    'uid': myUid,
    'name': str(u['name']),
    'photoUrl': str(u['photoUrl']),
    'ts': ServerValue.timestamp,
  };
}

Future<void> _postPhotoStatus(BuildContext context) async {
  final f = await pickImageFile();
  if (f == null) return;
  if (context.mounted) toast(context, 'Mengunggah status...');
  try {
    final key = db.ref('statuses/$myUid').push().key!;
    final url = await uploadFile('status_media/$myUid/$key.jpg', f, 'image/jpeg');
    final base = await _statusBase();
    await db.ref('statuses/$myUid/$key').set({...base, 'type': 'image', 'url': url});
    if (context.mounted) toast(context, 'Status terkirim');
  } catch (e) {
    if (context.mounted) toast(context, 'Gagal: $e');
  }
}

Future<void> _postTextStatus(BuildContext context) async {
  final ctl = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      backgroundColor: kCard,
      title: const Text('Status teks'),
      content: TextField(
          controller: ctl,
          maxLines: 4,
          maxLength: 200,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(hintText: 'Tulis status...', fillColor: kBg)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Kirim')),
      ],
    ),
  );
  final t = ctl.text.trim();
  ctl.dispose();
  if (ok != true || t.isEmpty) return;
  try {
    final ref = db.ref('statuses/$myUid').push();
    final base = await _statusBase();
    await ref.set({...base, 'type': 'text', 'text': t});
  } catch (e) {
    if (context.mounted) toast(context, 'Gagal: $e');
  }
}

class StatusBar extends StatelessWidget {
  const StatusBar({super.key});

  Widget _tile(BuildContext context, String name, String photo, bool ring,
      VoidCallback onTap, {bool plus = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 74,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Column(children: [
          Stack(children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: ring ? Colors.white : kLine, width: 2)),
              child: Avatar(name: name, url: photo, r: 25),
            ),
            if (plus)
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle),
                  child: const Icon(Icons.add, color: Colors.black, size: 18),
                ),
              ),
          ]),
          const SizedBox(height: 4),
          Text(name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: kHint)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => DbValue(
        path: 'statuses',
        builder: (c, v, loaded) {
          final now = DateTime.now().millisecondsSinceEpoch;
          final byUser = <String, List<Map<String, dynamic>>>{};
          asMap(v).forEach((uid, items) {
            asMap(items).forEach((k, it) {
              final m = asMap(it);
              m['key'] = k;
              if (now - tsOf(m) < 86400000 && tsOf(m) > 0) {
                byUser.putIfAbsent(uid, () => []).add(m);
              }
            });
          });
          for (final l in byUser.values) {
            l.sort((a, b) => tsOf(a).compareTo(tsOf(b)));
          }
          final mine = byUser[myUid];
          final others = byUser.entries.where((e) => e.key != myUid).toList();
          return SizedBox(
            height: 98,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              children: [
                _tile(
                  c,
                  'Status saya',
                  mine == null ? '' : str(mine.first['photoUrl']),
                  mine != null,
                  () {
                    if (mine == null) {
                      addStatusSheet(c);
                    } else {
                      Navigator.push(
                          c,
                          MaterialPageRoute(
                              builder: (_) =>
                                  StatusViewer(items: mine, isMine: true)));
                    }
                  },
                  plus: mine == null,
                ),
                for (final e in others)
                  _tile(
                    c,
                    str(e.value.first['name']),
                    str(e.value.first['photoUrl']),
                    true,
                    () => Navigator.push(
                        c,
                        MaterialPageRoute(
                            builder: (_) =>
                                StatusViewer(items: e.value, isMine: false))),
                  ),
              ],
            ),
          );
        },
      );
}

class StatusViewer extends StatefulWidget {
  final List<Map<String, dynamic>> items;
  final bool isMine;
  const StatusViewer({super.key, required this.items, required this.isMine});
  @override
  State<StatusViewer> createState() => _StatusViewerState();
}

class _StatusViewerState extends State<StatusViewer>
    with SingleTickerProviderStateMixin {
  late final AnimationController ac;
  int idx = 0;

  @override
  void initState() {
    super.initState();
    ac = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..addStatusListener((st) {
        if (st == AnimationStatus.completed) _next();
      });
    ac.forward();
  }

  @override
  void dispose() {
    ac.dispose();
    super.dispose();
  }

  void _next() {
    if (idx < widget.items.length - 1) {
      setState(() => idx++);
      ac.forward(from: 0);
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (idx > 0) setState(() => idx--);
    ac.forward(from: 0);
  }

  Future<void> _delete() async {
    ac.stop();
    final it = widget.items[idx];
    await db.ref('statuses/$myUid/${it['key']}').remove();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final it = widget.items[idx];
    final isImg = str(it['type']) == 'image';
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.globalPosition.dx < w / 3) {
            _prev();
          } else {
            _next();
          }
        },
        child: Stack(children: [
          Positioned.fill(
            child: isImg
                ? Image.network(str(it['url']),
                    fit: BoxFit.contain,
                    errorBuilder: (c, e, s2) =>
                        const Center(child: Icon(Icons.broken_image, color: kHint)))
                : Container(
                    color: kCard,
                    padding: const EdgeInsets.all(32),
                    alignment: Alignment.center,
                    child: Text(str(it['text']),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w700)),
                  ),
          ),
          SafeArea(
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                child: AnimatedBuilder(
                  animation: ac,
                  builder: (c, w) => Row(children: [
                    for (var i = 0; i < widget.items.length; i++)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: LinearProgressIndicator(
                            value: i < idx ? 1 : (i == idx ? ac.value : 0),
                            minHeight: 3,
                            color: Colors.white,
                            backgroundColor: Colors.white24,
                          ),
                        ),
                      ),
                  ]),
                ),
              ),
              ListTile(
                leading: Avatar(
                    name: str(it['name']), url: str(it['photoUrl']), r: 18),
                title: Text(str(it['name']),
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(hhmm(tsOf(it)),
                    style: const TextStyle(color: kHint, fontSize: 12)),
                trailing: widget.isMine
                    ? IconButton(
                        icon: const Icon(Icons.delete_outline), onPressed: _delete)
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.pop(context)),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ═══════════════════════ TAB GRUP ═══════════════════════
class GroupsTab extends StatelessWidget {
  const GroupsTab({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Grup')),
        floatingActionButton: FloatingActionButton(
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const CreateGroupPage())),
          child: const Icon(Icons.group_add),
        ),
        body: DbValue(
          path: 'groups',
          builder: (c, v, loaded) {
            if (!loaded) return const Center(child: CircularProgressIndicator());
            final list = mapValues(v)
                .where((g) => asMap(g['members'])[myUid] == true)
                .toList()
              ..sort((a, b) => str(a['name'])
                  .toLowerCase()
                  .compareTo(str(b['name']).toLowerCase()));
            if (list.isEmpty) {
              return const Center(
                  child: Text('Belum ada grup. Ketuk tombol untuk membuat.',
                      style: TextStyle(color: kHint)));
            }
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, i) => const Divider(height: 1, indent: 76),
              itemBuilder: (c, i) {
                final g = list[i];
                return ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: const Avatar(icon: Icons.groups, r: 26),
                  title: Text(str(g['name']),
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 16)),
                  subtitle: Text('${asMap(g['members']).length} anggota',
                      style: const TextStyle(color: kHint)),
                  onTap: () => Navigator.push(
                      c,
                      MaterialPageRoute(
                          builder: (_) => GroupChatPage(id: str(g['id'])))),
                );
              },
            );
          },
        ),
      );
}

class CreateGroupPage extends StatefulWidget {
  const CreateGroupPage({super.key});
  @override
  State<CreateGroupPage> createState() => _CreateGroupPageState();
}

class _CreateGroupPageState extends State<CreateGroupPage> {
  final name = TextEditingController();
  final sel = <String>{};
  bool busy = false;

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  Future<void> create() async {
    final n = name.text.trim();
    if (n.isEmpty) {
      toast(context, 'Isi nama grup');
      return;
    }
    setState(() => busy = true);
    try {
      final ref = db.ref('groups').push();
      await ref.set({
        'id': ref.key,
        'name': n,
        'adminId': myUid,
        'admins': {myUid: true},
        'members': {myUid: true, for (final id in sel) id: true},
        'createdAt': ServerValue.timestamp,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() => busy = false);
        toast(context, 'Gagal: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Grup Baru'),
          actions: [
            TextButton(
                onPressed: busy ? null : create,
                child: const Text('Buat',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          ],
        ),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: name,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Nama grup'),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Undang anggota', style: TextStyle(color: kHint))),
          ),
          Expanded(
            child: DbValue(
              path: 'users',
              builder: (c, v, loaded) {
                final list = mapValues(v).where((u) => str(u['uid']) != myUid).toList();
                return ListView(
                  children: list.map((u) {
                    final id = str(u['uid']);
                    return CheckboxListTile(
                      activeColor: Colors.white,
                      checkColor: Colors.black,
                      value: sel.contains(id),
                      onChanged: (val) => setState(
                          () => val == true ? sel.add(id) : sel.remove(id)),
                      secondary:
                          Avatar(name: str(u['name']), url: str(u['photoUrl'])),
                      title: NameRow(
                          name: str(u['name']), verified: u['isVerified'] == true),
                      subtitle: Text('@${str(u['username'])}',
                          style: const TextStyle(color: kHint)),
                    );
                  }).toList(),
                );
              },
            ),
          ),
        ]),
      );
}

class GroupChatPage extends StatelessWidget {
  final String id;
  const GroupChatPage({super.key, required this.id});
  @override
  Widget build(BuildContext context) => DbValue(
        path: 'groups/$id',
        builder: (c, v, loaded) {
          final g = asMap(v);
          if (g.isEmpty) {
            return Scaffold(
                appBar: AppBar(),
                body: Center(
                    child: loaded
                        ? const Text('Grup tidak ditemukan',
                            style: TextStyle(color: kHint))
                        : const CircularProgressIndicator()));
          }
          final admins = asMap(g['admins']).keys.toSet();
          return Scaffold(
            appBar: AppBar(
              titleSpacing: 0,
              title: GestureDetector(
                onTap: () => Navigator.push(
                    c, MaterialPageRoute(builder: (_) => GroupInfoPage(id: id))),
                child: Row(children: [
                  const Avatar(icon: Icons.groups, r: 18),
                  const SizedBox(width: 10),
                  Flexible(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(str(g['name']),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w600)),
                          Text('${asMap(g['members']).length} anggota',
                              style: const TextStyle(fontSize: 12, color: kHint)),
                        ]),
                  ),
                ]),
              ),
            ),
            body: MessageThread(
                base: 'groups/$id', showSender: true, admins: admins),
          );
        },
      );
}

class GroupInfoPage extends StatelessWidget {
  final String id;
  const GroupInfoPage({super.key, required this.id});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Info Grup')),
        body: DbValue(
          path: 'groups/$id',
          builder: (c, gv, _) {
            final g = asMap(gv);
            if (g.isEmpty) return const Center(child: CircularProgressIndicator());
            final members = asMap(g['members']).keys.toList();
            final admins = asMap(g['admins']);
            final iAdmin = admins[myUid] == true;
            return DbValue(
              path: 'users',
              builder: (c2, uv, _) {
                final users = asMap(uv).map((k, e) => MapEntry(k, asMap(e)));
                return ListView(children: [
                  const SizedBox(height: 20),
                  const Center(child: Avatar(icon: Icons.groups, r: 48)),
                  const SizedBox(height: 12),
                  Center(
                      child: Text(str(g['name']),
                          style: const TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w800))),
                  const SizedBox(height: 4),
                  Center(
                      child: Text('${members.length} anggota',
                          style: const TextStyle(color: kHint))),
                  const SizedBox(height: 16),
                  const Divider(height: 1),
                  for (final uid in members)
                    ListTile(
                      leading: Avatar(
                          name: str(users[uid]?['name']),
                          url: str(users[uid]?['photoUrl'])),
                      title: NameRow(
                          name: str(users[uid]?['name']).isEmpty
                              ? uid
                              : str(users[uid]?['name']),
                          verified: users[uid]?['isVerified'] == true),
                      subtitle: Text('@${str(users[uid]?['username'])}',
                          style: const TextStyle(color: kHint)),
                      trailing: admins[uid] == true
                          ? const Text('Admin',
                              style: TextStyle(color: kHint, fontSize: 12))
                          : (iAdmin && uid != myUid
                              ? IconButton(
                                  icon: const Icon(Icons.person_remove_outlined,
                                      color: kRed),
                                  onPressed: () => db
                                      .ref('groups/$id/members/$uid')
                                      .remove())
                              : null),
                    ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.exit_to_app, color: kRed),
                    title: const Text('Keluar dari grup',
                        style: TextStyle(color: kRed)),
                    onTap: () async {
                      final nav = Navigator.of(context);
                      await db.ref('groups/$id/members/$myUid').remove();
                      await db.ref('groups/$id/admins/$myUid').remove();
                      nav.popUntil((r) => r.isFirst);
                    },
                  ),
                  if (iAdmin)
                    ListTile(
                      leading: const Icon(Icons.delete_forever, color: kRed),
                      title: const Text('Hapus grup',
                          style: TextStyle(color: kRed)),
                      onTap: () async {
                        final nav = Navigator.of(context);
                        await db.ref('groups/$id').remove();
                        nav.popUntil((r) => r.isFirst);
                      },
                    ),
                ]);
              },
            );
          },
        ),
      );
}

// ═══════════════════════ THREAD PESAN (chat, grup, saluran) ═══════════════════════
class Msg {
  final String key;
  final Map<String, dynamic> d;
  Msg(this.key, this.d);
}

const kStickers = [
  '😀', '😂', '🥰', '😍', '😎', '🤩', '😭', '😡',
  '🥳', '😴', '🤔', '🙄', '😱', '🤗', '😇', '🤯',
  '👍', '👎', '👏', '🙏', '💪', '🔥', '❤️', '💔',
  '🎉', '🎁', '⭐', '💯', '✅', '❌', '🚀', '🌹',
  '🐱', '🐶', '🦁', '🐼', '🍕', '🍔', '☕', '⚽',
];

class MessageThread extends StatefulWidget {
  final String base;
  final bool canSend;
  final bool showSender;
  final Set<String> admins;
  final Widget? readOnly;
  const MessageThread({
    super.key,
    required this.base,
    this.canSend = true,
    this.showSender = false,
    this.admins = const {},
    this.readOnly,
  });
  @override
  State<MessageThread> createState() => _MessageThreadState();
}

class _MessageThreadState extends State<MessageThread> {
  final ctl = TextEditingController();
  final focus = FocusNode();
  late final Stream<DatabaseEvent> _stream;
  final AudioRecorder _rec = AudioRecorder();
  StreamSubscription<Amplitude>? _ampSub;
  Timer? _timer;
  bool showEmoji = false, recording = false, uploading = false, hasText = false;
  int recSec = 0;
  final List<double> amps = [];
  String? recPath;

  @override
  void initState() {
    super.initState();
    _stream = db.ref('${widget.base}/messages').limitToLast(300).onValue;
    ctl.addListener(() {
      final h = ctl.text.trim().isNotEmpty;
      if (h != hasText && mounted) setState(() => hasText = h);
    });
    focus.addListener(() {
      if (focus.hasFocus && showEmoji && mounted) setState(() => showEmoji = false);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ampSub?.cancel();
    _rec.dispose();
    ctl.dispose();
    focus.dispose();
    super.dispose();
  }

  Future<void> _push(Map<String, Object?> data) async {
    final u = FirebaseAuth.instance.currentUser!;
    await db.ref('${widget.base}/messages').push().set({
      'senderId': u.uid,
      'senderName': u.displayName ?? '',
      ...data,
      'ts': ServerValue.timestamp,
    });
  }

  Future<void> _sendText() async {
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    ctl.clear();
    try {
      await _push({'type': 'text', 'text': t});
    } catch (e) {
      if (mounted) toast(context, 'Gagal kirim: $e');
    }
  }

  Future<void> _sendSticker(String emoji) async {
    try {
      await _push({'type': 'sticker', 'text': emoji});
    } catch (e) {
      if (mounted) toast(context, 'Gagal kirim: $e');
    }
  }

  Future<void> _sendMedia(File f, String type) async {
    setState(() => uploading = true);
    try {
      final ts = DateTime.now().millisecondsSinceEpoch;
      final isImg = type == 'image';
      final name = '${myUid}_$ts${isImg ? '.jpg' : '.mp4'}';
      final url = await uploadFile(
          'chat_media/$name', f, isImg ? 'image/jpeg' : 'video/mp4');
      await _push({'type': type, 'url': url});
    } catch (e) {
      if (mounted) toast(context, 'Gagal upload: $e');
    }
    if (mounted) setState(() => uploading = false);
  }

  void _attach() {
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          sheetTile(Icons.photo_outlined, 'Foto dari galeri', () async {
            Navigator.pop(c);
            final f = await pickImageFile();
            if (f != null) _sendMedia(f, 'image');
          }),
          sheetTile(Icons.photo_camera_outlined, 'Kamera', () async {
            Navigator.pop(c);
            final f = await pickImageFile(src: ImageSource.camera);
            if (f != null) _sendMedia(f, 'image');
          }),
          sheetTile(Icons.videocam_outlined, 'Video dari galeri', () async {
            Navigator.pop(c);
            final x = await _picker.pickVideo(
                source: ImageSource.gallery,
                maxDuration: const Duration(minutes: 3));
            if (x != null) _sendMedia(File(x.path), 'video');
          }),
        ]),
      ),
    );
  }

  void _stickers() {
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: SizedBox(
          height: 300,
          child: GridView.count(
            crossAxisCount: 5,
            padding: const EdgeInsets.all(12),
            children: [
              for (final e in kStickers)
                InkWell(
                  onTap: () {
                    Navigator.pop(c);
                    _sendSticker(e);
                  },
                  child: Center(
                      child: Text(e, style: const TextStyle(fontSize: 36))),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Voice note ──
  Future<void> _startRec() async {
    try {
      if (!await _rec.hasPermission()) {
        if (mounted) toast(context, 'Izin mikrofon ditolak');
        return;
      }
      final dir = await getTemporaryDirectory();
      recPath = '${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc),
          path: recPath!);
      amps.clear();
      recSec = 0;
      _ampSub = _rec
          .onAmplitudeChanged(const Duration(milliseconds: 100))
          .listen((a) {
        final v = ((a.current + 45) / 45).clamp(0.0, 1.0).toDouble();
        amps.add(v);
        if (mounted) setState(() {});
      });
      _timer = Timer.periodic(const Duration(seconds: 1), (t) {
        if (mounted) setState(() => recSec++);
      });
      setState(() => recording = true);
    } catch (e) {
      if (mounted) toast(context, 'Gagal merekam: $e');
    }
  }

  List<int> _downsample(List<double> a, int n) {
    if (a.isEmpty) return List<int>.filled(n, 15);
    final out = <int>[];
    for (var i = 0; i < n; i++) {
      final s0 = (i * a.length / n).floor();
      var e0 = ((i + 1) * a.length / n).floor();
      if (e0 <= s0) e0 = s0 + 1;
      if (e0 > a.length) e0 = a.length;
      var sum = 0.0;
      for (var j = s0; j < e0; j++) {
        sum += a[j];
      }
      out.add(((sum / (e0 - s0)) * 100).round().clamp(8, 100).toInt());
    }
    return out;
  }

  Future<void> _finishRec({bool send = true}) async {
    _timer?.cancel();
    await _ampSub?.cancel();
    final sec = recSec;
    final wave = _downsample(amps, 36);
    String? p;
    try {
      p = await _rec.stop();
    } catch (_) {}
    if (mounted) setState(() => recording = false);
    if (!send || p == null || sec < 1) {
      if (p != null) {
        try {
          File(p).deleteSync();
        } catch (_) {}
      }
      return;
    }
    if (mounted) setState(() => uploading = true);
    try {
      final ts = DateTime.now().millisecondsSinceEpoch;
      final url =
          await uploadFile('chat_media/vn_${myUid}_$ts.m4a', File(p), 'audio/mp4');
      await _push({'type': 'voice', 'url': url, 'duration': sec, 'wave': wave});
    } catch (e) {
      if (mounted) toast(context, 'Gagal kirim VN: $e');
    }
    if (mounted) setState(() => uploading = false);
  }

  // ── Menu long-press ala iOS ──
  Future<void> _react(Msg m, String emoji) async {
    final ref = db.ref('${widget.base}/messages/${m.key}/reactions/$myUid');
    if (str(asMap(m.d['reactions'])[myUid]) == emoji) {
      await ref.remove();
    } else {
      await ref.set(emoji);
    }
  }

  void _menu(Msg m, bool mine) {
    final canDelete = mine || widget.admins.contains(myUid);
    final isText = str(m.d['type']).isEmpty || str(m.d['type']) == 'text';
    Widget item(IconData i, String t, VoidCallback f, {Color color = Colors.white}) =>
        InkWell(
          onTap: f,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            child: Row(children: [
              Icon(i, color: color, size: 20),
              const SizedBox(width: 12),
              Text(t, style: TextStyle(color: color, fontSize: 15)),
            ]),
          ),
        );
    blurPopup(
      context,
      (ctx) => Container(
        width: 270,
        decoration: BoxDecoration(
            color: const Color.fromRGBO(28, 28, 30, 0.8),
            borderRadius: BorderRadius.circular(18)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              for (final e in ['❤️', '👍', '😂', '😮', '😢', '🙏'])
                GestureDetector(
                  onTap: () {
                    Navigator.pop(ctx);
                    _react(m, e);
                  },
                  child: Text(e, style: const TextStyle(fontSize: 26)),
                ),
            ]),
          ),
          const Divider(height: 1),
          if (isText)
            item(Icons.copy, 'Salin', () {
              Clipboard.setData(ClipboardData(text: str(m.d['text'])));
              Navigator.pop(ctx);
              toast(context, 'Disalin');
            }),
          if (canDelete)
            item(Icons.delete_outline, 'Hapus', () {
              Navigator.pop(ctx);
              db.ref('${widget.base}/messages/${m.key}').remove();
            }, color: kRed),
          if (!isText && !canDelete)
            const Padding(
                padding: EdgeInsets.all(14),
                child: Text('Tidak ada aksi', style: TextStyle(color: kHint))),
        ]),
      ),
    );
  }

  // ── UI ──
  Widget _recBar() {
    final tail = amps.length > 32 ? amps.sublist(amps.length - 32) : amps;
    return Container(
      color: kBar,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
      child: Row(children: [
        IconButton(
            icon: const Icon(Icons.delete_outline, color: kRed),
            onPressed: () => _finishRec(send: false)),
        const Icon(Icons.fiber_manual_record, color: kRed, size: 12),
        const SizedBox(width: 6),
        Text(mmss(recSec), style: const TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(width: 12),
        Expanded(
          child: SizedBox(
            height: 30,
            child: CustomPaint(
              painter: WavePainter(
                  tail.map((e) => (e * 100).round().clamp(8, 100).toInt()).toList(),
                  1.0,
                  Colors.white,
                  Colors.white),
              size: Size.infinite,
            ),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _finishRec(),
          child: const CircleAvatar(
              radius: 20,
              backgroundColor: Colors.white,
              child: Icon(Icons.send, color: Colors.black, size: 20)),
        ),
        const SizedBox(width: 4),
      ]),
    );
  }

  Widget _inputBar() {
    if (recording) return _recBar();
    return Container(
      color: kBar,
      padding: const EdgeInsets.fromLTRB(4, 6, 6, 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        IconButton(
            icon: const Icon(Icons.add_circle_outline),
            onPressed: uploading ? null : _attach),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
                color: kCard, borderRadius: BorderRadius.circular(22)),
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const SizedBox(width: 14),
              Expanded(
                child: TextField(
                  controller: ctl,
                  focusNode: focus,
                  minLines: 1,
                  maxLines: 5,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: 'Pesan',
                    filled: false,
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(showEmoji ? Icons.keyboard : Icons.emoji_emotions_outlined),
                onPressed: () {
                  if (showEmoji) {
                    setState(() => showEmoji = false);
                    focus.requestFocus();
                  } else {
                    focus.unfocus();
                    setState(() => showEmoji = true);
                  }
                },
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.sticky_note_2_outlined),
                onPressed: _stickers,
              ),
            ]),
          ),
        ),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: hasText ? _sendText : (uploading ? null : _startRec),
          child: CircleAvatar(
            radius: 21,
            backgroundColor: Colors.white,
            child: Icon(hasText ? Icons.send : Icons.mic,
                color: Colors.black, size: 21),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        child: StreamBuilder<DatabaseEvent>(
          stream: _stream,
          builder: (c, snap) {
            if (snap.hasError) {
              return Center(
                  child: Text('Gagal memuat: ${snap.error}',
                      style: const TextStyle(color: kHint)));
            }
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final msgs = <Msg>[];
            for (final ch in snap.data!.snapshot.children) {
              msgs.add(Msg(ch.key ?? '', asMap(ch.value)));
            }
            if (msgs.isEmpty) {
              return const Center(
                  child: Text('Belum ada pesan', style: TextStyle(color: kHint)));
            }
            final rev = msgs.reversed.toList();
            return ListView.builder(
              reverse: true,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              itemCount: rev.length,
              itemBuilder: (c, i) {
                final m = rev[i];
                final mine = str(m.d['senderId']) == myUid;
                return MsgBubble(
                  m: m.d,
                  mine: mine,
                  showSender: widget.showSender,
                  onLong: () => _menu(m, mine),
                );
              },
            );
          },
        ),
      ),
      if (uploading)
        const LinearProgressIndicator(
            minHeight: 2, color: Colors.white, backgroundColor: kLine),
      if (widget.canSend) ...[
        SafeArea(top: false, child: _inputBar()),
        if (showEmoji)
          SizedBox(
            height: 256,
            child: EmojiPicker(
              textEditingController: ctl,
              config: Config(
                height: 256,
                emojiViewConfig:
                    EmojiViewConfig(backgroundColor: kCard, columns: 8),
                categoryViewConfig: CategoryViewConfig(
                  backgroundColor: kBar,
                  indicatorColor: Colors.white,
                  iconColor: kHint,
                  iconColorSelected: Colors.white,
                ),
                bottomActionBarConfig: BottomActionBarConfig(
                  backgroundColor: kBar,
                  buttonColor: kBar,
                  buttonIconColor: Colors.white,
                ),
              ),
            ),
          ),
      ] else if (widget.readOnly != null)
        SafeArea(top: false, child: widget.readOnly!),
    ]);
  }
}

// ═══════════════════════ BUBBLE ═══════════════════════
class MsgBubble extends StatelessWidget {
  final Map<String, dynamic> m;
  final bool mine, showSender;
  final VoidCallback onLong;
  const MsgBubble(
      {super.key,
      required this.m,
      required this.mine,
      required this.showSender,
      required this.onLong});

  @override
  Widget build(BuildContext context) {
    final type = str(m['type']).isEmpty ? 'text' : str(m['type']);
    final fg = mine ? Colors.black : Colors.white;
    final sub = mine ? const Color(0x99000000) : kHint;
    final time = Text(hhmm(tsOf(m)), style: TextStyle(fontSize: 10.5, color: sub));
    final maxW = MediaQuery.of(context).size.width * 0.74;
    final react = asMap(m['reactions']);

    Widget inner;
    var bubble = true;
    switch (type) {
      case 'sticker':
        bubble = false;
        inner = SizedBox(
            width: 120,
            height: 120,
            child: Center(
                child: Text(str(m['text']), style: const TextStyle(fontSize: 84))));
        break;
      case 'image':
        inner = GestureDetector(
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => PhotoViewPage(url: str(m['url'])))),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(str(m['url']),
                width: 230,
                fit: BoxFit.cover,
                loadingBuilder: (c, w, p) => p == null
                    ? w
                    : const SizedBox(
                        width: 230,
                        height: 160,
                        child: Center(child: CircularProgressIndicator())),
                errorBuilder: (c, e, s2) => const SizedBox(
                    width: 230,
                    height: 120,
                    child: Icon(Icons.broken_image, color: kHint))),
          ),
        );
        break;
      case 'video':
        inner = GestureDetector(
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => VideoPage(url: str(m['url'])))),
          child: Container(
            width: 230,
            height: 150,
            decoration: BoxDecoration(
                color: Colors.black, borderRadius: BorderRadius.circular(12)),
            child: const Center(
                child: Icon(Icons.play_circle_fill, color: Colors.white, size: 54)),
          ),
        );
        break;
      case 'voice':
        inner = VoicePlayer(
          url: str(m['url']),
          seconds: m['duration'] is num ? (m['duration'] as num).toInt() : 0,
          wave: (m['wave'] is List)
              ? (m['wave'] as List).map((e) => (e as num).toInt()).toList()
              : <int>[],
          mine: mine,
        );
        break;
      default:
        inner = Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Flexible(
              child: Text(str(m['text']),
                  style: TextStyle(color: fg, fontSize: 15.5))),
          const SizedBox(width: 8),
          time,
        ]);
    }

    Widget body = bubble
        ? Container(
            constraints: BoxConstraints(maxWidth: maxW),
            padding: (type == 'image' || type == 'video')
                ? const EdgeInsets.all(3)
                : const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: mine ? Colors.white : kCard,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(18),
                topRight: const Radius.circular(18),
                bottomLeft: Radius.circular(mine ? 18 : 4),
                bottomRight: Radius.circular(mine ? 4 : 18),
              ),
            ),
            child: inner,
          )
        : inner;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.5),
      child: Column(
        crossAxisAlignment:
            mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (showSender && !mine)
            Padding(
              padding: const EdgeInsets.only(left: 6, bottom: 2),
              child: Text(str(m['senderName']),
                  style: const TextStyle(
                      fontSize: 11.5, color: kHint, fontWeight: FontWeight.w600)),
            ),
          GestureDetector(onLongPress: onLong, child: body),
          if (react.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: kLine)),
                child: Text(react.values.map(str).join(' '),
                    style: const TextStyle(fontSize: 13)),
              ),
            ),
        ],
      ),
    );
  }
}

// ═══════════════════════ VOICE PLAYER + WAVEFORM ═══════════════════════
class WavePainter extends CustomPainter {
  final List<int> bars;
  final double progress;
  final Color played, idle;
  WavePainter(this.bars, this.progress, this.played, this.idle);

  @override
  void paint(Canvas canvas, Size size) {
    if (bars.isEmpty) return;
    final n = bars.length;
    final slot = size.width / n;
    final w = slot * 0.55;
    final p = Paint()..strokeCap = StrokeCap.round..strokeWidth = w;
    for (var i = 0; i < n; i++) {
      final h = (bars[i] / 100) * size.height;
      final x = slot * i + slot / 2;
      p.color = (i / n) < progress ? played : idle;
      canvas.drawLine(Offset(x, (size.height - h) / 2),
          Offset(x, (size.height + h) / 2), p);
    }
  }

  @override
  bool shouldRepaint(covariant WavePainter o) =>
      o.progress != progress || o.bars.length != bars.length || o.played != played;
}

class VoicePlayer extends StatefulWidget {
  final String url;
  final int seconds;
  final List<int> wave;
  final bool mine;
  const VoicePlayer(
      {super.key,
      required this.url,
      required this.seconds,
      required this.wave,
      required this.mine});
  @override
  State<VoicePlayer> createState() => _VoicePlayerState();
}

class _VoicePlayerState extends State<VoicePlayer> {
  final AudioPlayer _p = AudioPlayer();
  final List<StreamSubscription> _subs = [];
  bool playing = false, started = false;
  Duration pos = Duration.zero;
  Duration? dur;

  @override
  void initState() {
    super.initState();
    _subs.add(_p.onPlayerStateChanged.listen((st) {
      if (mounted) setState(() => playing = st == PlayerState.playing);
    }));
    _subs.add(_p.onPositionChanged.listen((d) {
      if (mounted) setState(() => pos = d);
    }));
    _subs.add(_p.onDurationChanged.listen((d) {
      if (mounted) setState(() => dur = d);
    }));
    _subs.add(_p.onPlayerComplete.listen((_) {
      if (mounted) {
        setState(() {
          pos = Duration.zero;
          playing = false;
          started = false;
        });
      }
    }));
  }

  @override
  void dispose() {
    for (final s0 in _subs) {
      s0.cancel();
    }
    _p.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      if (playing) {
        await _p.pause();
      } else if (started) {
        await _p.resume();
      } else {
        started = true;
        await _p.play(UrlSource(widget.url));
      }
    } catch (_) {
      started = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final fg = widget.mine ? Colors.black : Colors.white;
    final total = (dur?.inMilliseconds ?? widget.seconds * 1000);
    final prog = total <= 0 ? 0.0 : (pos.inMilliseconds / total).clamp(0.0, 1.0);
    final shown = playing || pos > Duration.zero ? pos.inSeconds : widget.seconds;
    final bars = widget.wave.isEmpty ? List<int>.filled(36, 20) : widget.wave;
    return SizedBox(
      width: 220,
      child: Row(children: [
        GestureDetector(
          onTap: _toggle,
          child: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
              color: fg, size: 38),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: SizedBox(
            height: 30,
            child: CustomPaint(
              painter: WavePainter(bars, prog.toDouble(), fg, fg.withOpacity(0.4)),
              size: Size.infinite,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Text(mmss(shown),
            style: TextStyle(
                color: widget.mine ? const Color(0x99000000) : kHint,
                fontSize: 11.5)),
      ]),
    );
  }
}

// ═══════════════════════ SALURAN ═══════════════════════
// Skema: /channels/{id} = {id, name, description, photoUrl, creatorUid, createdAt, members:{uid:true}, admins:{uid:true}}
String chCreator(Map<String, dynamic> ch) =>
    str(ch['creatorUid']).isNotEmpty ? str(ch['creatorUid']) : str(ch['adminId']);

Map<String, dynamic> chMembers(Map<String, dynamic> ch) =>
    asMap(ch['members']).isNotEmpty ? asMap(ch['members']) : asMap(ch['followers']);

bool chIsAdmin(Map<String, dynamic> ch) =>
    chCreator(ch) == myUid || asMap(ch['admins'])[myUid] == true;

class ChannelsTab extends StatelessWidget {
  const ChannelsTab({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Saluran')),
        floatingActionButton: FloatingActionButton(
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const CreateChannelPage())),
          child: const Icon(Icons.campaign),
        ),
        body: DbValue(
          path: 'channels',
          builder: (c, v, loaded) {
            if (!loaded) return const Center(child: CircularProgressIndicator());
            final list = mapValues(v)
              ..sort((a, b) => str(a['name'])
                  .toLowerCase()
                  .compareTo(str(b['name']).toLowerCase()));
            if (list.isEmpty) {
              return const Center(
                  child: Text('Belum ada saluran. Ketuk tombol untuk membuat.',
                      style: TextStyle(color: kHint)));
            }
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, i) => const Divider(height: 1, indent: 76),
              itemBuilder: (c, i) {
                final ch = list[i];
                final isAdmin = chIsAdmin(ch);
                final member = chMembers(ch)[myUid] == true;
                return ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: Avatar(
                      url: str(ch['photoUrl']), icon: Icons.campaign, r: 26),
                  title: NameRow(
                      name: str(ch['name']),
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 16)),
                  subtitle: Text(
                      str(ch['description']).isEmpty
                          ? '${chMembers(ch).length} pengikut'
                          : str(ch['description']),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: kHint)),
                  trailing: isAdmin
                      ? const Text('Admin',
                          style: TextStyle(color: kHint, fontSize: 12))
                      : (member
                          ? null
                          : const Text('Ikuti',
                              style: TextStyle(fontWeight: FontWeight.w700))),
                  onTap: () => Navigator.push(
                      c,
                      MaterialPageRoute(
                          builder: (_) => ChannelPage(id: str(ch['id'])))),
                );
              },
            );
          },
        ),
      );
}

class CreateChannelPage extends StatefulWidget {
  const CreateChannelPage({super.key});
  @override
  State<CreateChannelPage> createState() => _CreateChannelPageState();
}

class _CreateChannelPageState extends State<CreateChannelPage> {
  final name = TextEditingController();
  final desc = TextEditingController();
  File? photo;
  bool busy = false;

  @override
  void dispose() {
    name.dispose();
    desc.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final f = await pickImageFile(size: 1024);
    if (f != null) setState(() => photo = f);
  }

  Future<void> _create() async {
    final n = name.text.trim();
    if (n.isEmpty) {
      toast(context, 'Isi nama saluran');
      return;
    }
    setState(() => busy = true);
    try {
      final ref = db.ref('channels').push();
      final id = ref.key!;
      var url = '';
      if (photo != null) {
        url = await uploadFile('channel_photos/$id.jpg', photo!, 'image/jpeg');
      }
      await ref.set({
        'id': id,
        'name': n,
        'description': desc.text.trim(),
        'photoUrl': url,
        'creatorUid': myUid,
        'adminId': myUid,
        'admins': {myUid: true},
        'members': {myUid: true},
        'createdAt': ServerValue.timestamp,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() => busy = false);
        toast(context, 'Gagal: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Saluran Baru'),
          actions: [
            TextButton(
                onPressed: busy ? null : _create,
                child: busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Buat',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          ],
        ),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Center(
            child: CircleAvatar(
              radius: 40,
              backgroundColor: kCard,
              backgroundImage: photo == null ? null : FileImage(photo!),
              child: photo == null
                  ? const Icon(Icons.campaign, size: 36, color: Colors.white)
                  : null,
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: kLine)),
              onPressed: busy ? null : _pick,
              icon: const Icon(Icons.photo_library_outlined, size: 18),
              label: const Text('Pilih Foto Channel'),
            ),
          ),
          const SizedBox(height: 22),
          TextField(
              controller: name,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Nama Saluran')),
          const SizedBox(height: 12),
          TextField(
              controller: desc,
              maxLines: 3,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Deskripsi')),
        ]),
      );
}

class ChannelPage extends StatelessWidget {
  final String id;
  const ChannelPage({super.key, required this.id});
  @override
  Widget build(BuildContext context) => DbValue(
        path: 'channels/$id',
        builder: (c, v, loaded) {
          final ch = asMap(v);
          if (ch.isEmpty) {
            return Scaffold(
                appBar: AppBar(),
                body: Center(
                    child: loaded
                        ? const Text('Saluran tidak ditemukan',
                            style: TextStyle(color: kHint))
                        : const CircularProgressIndicator()));
          }
          final isAdmin = chIsAdmin(ch);
          final member = chMembers(ch)[myUid] == true;
          final mref = db.ref('channels/$id/members/$myUid');
          return Scaffold(
            appBar: AppBar(
              titleSpacing: 0,
              title: GestureDetector(
                onTap: () => Navigator.push(c,
                    MaterialPageRoute(builder: (_) => ChannelInfoPage(id: id))),
                child: Row(children: [
                  Avatar(url: str(ch['photoUrl']), icon: Icons.campaign, r: 18),
                  const SizedBox(width: 10),
                  Flexible(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          NameRow(
                              name: str(ch['name']),
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w600)),
                          Text('${chMembers(ch).length} pengikut',
                              style: const TextStyle(fontSize: 12, color: kHint)),
                        ]),
                  ),
                ]),
              ),
              actions: [
                if (!isAdmin)
                  IconButton(
                    icon: Icon(member
                        ? Icons.notifications_active
                        : Icons.notifications_none),
                    onPressed: () => member ? mref.remove() : mref.set(true),
                  ),
              ],
            ),
            body: MessageThread(
              base: 'channels/$id',
              canSend: isAdmin,
              admins: {chCreator(ch), ...asMap(ch['admins']).keys},
              readOnly: Container(
                color: kBar,
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                child: member
                    ? const Text('Hanya admin saluran yang dapat mengirim pesan',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: kHint))
                    : ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: Colors.black),
                        onPressed: () => mref.set(true),
                        child: const Text('Ikuti Saluran')),
              ),
            ),
          );
        },
      );
}

class ChannelInfoPage extends StatefulWidget {
  final String id;
  const ChannelInfoPage({super.key, required this.id});
  @override
  State<ChannelInfoPage> createState() => _ChannelInfoPageState();
}

class _ChannelInfoPageState extends State<ChannelInfoPage> {
  bool busy = false;

  Future<void> _change() async {
    final f = await pickImageFile(size: 1024);
    if (f == null) return;
    setState(() => busy = true);
    try {
      final url =
          await uploadFile('channel_photos/${widget.id}.jpg', f, 'image/jpeg');
      await db.ref('channels/${widget.id}/photoUrl').set(url);
      if (mounted) toast(context, 'Foto saluran diperbarui');
    } catch (e) {
      if (mounted) toast(context, 'Gagal: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _remove() async {
    setState(() => busy = true);
    try {
      await db.ref('channels/${widget.id}/photoUrl').set('');
      try {
        await FirebaseStorage.instance
            .ref('channel_photos/${widget.id}.jpg')
            .delete();
      } catch (_) {}
      if (mounted) toast(context, 'Foto saluran dihapus');
    } catch (e) {
      if (mounted) toast(context, 'Gagal: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  void _photoSheet(Map<String, dynamic> ch) {
    final url = str(ch['photoUrl']);
    final canEdit = chCreator(ch) == myUid;
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (url.isNotEmpty)
            sheetTile(Icons.visibility_outlined, 'Lihat Foto', () {
              Navigator.pop(c);
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => PhotoViewPage(url: url)));
            }),
          if (canEdit)
            sheetTile(Icons.photo_library_outlined, 'Ganti Foto', () {
              Navigator.pop(c);
              _change();
            }),
          if (canEdit && url.isNotEmpty)
            sheetTile(Icons.delete_outline, 'Hapus Foto', () {
              Navigator.pop(c);
              _remove();
            }, color: kRed),
          if (!canEdit && url.isEmpty)
            const Padding(
                padding: EdgeInsets.all(20),
                child: Text('Saluran ini belum punya foto',
                    style: TextStyle(color: kHint))),
        ]),
      ),
    );
  }

  Future<void> _editText(Map<String, dynamic> ch) async {
    final n = TextEditingController(text: str(ch['name']));
    final d = TextEditingController(text: str(ch['description']));
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: kCard,
        title: const Text('Edit Saluran'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: n,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Nama', fillColor: kBg)),
          const SizedBox(height: 10),
          TextField(
              controller: d,
              style: const TextStyle(color: Colors.white),
              decoration:
                  const InputDecoration(hintText: 'Deskripsi', fillColor: kBg)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Simpan')),
        ],
      ),
    );
    final nn = n.text.trim(), dd = d.text.trim();
    n.dispose();
    d.dispose();
    if (ok == true && nn.isNotEmpty) {
      await db
          .ref('channels/${widget.id}')
          .update(<String, Object?>{'name': nn, 'description': dd});
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Info Saluran')),
        body: DbValue(
          path: 'channels/${widget.id}',
          builder: (c, v, loaded) {
            final ch = asMap(v);
            if (ch.isEmpty) return const Center(child: CircularProgressIndicator());
            final creator = chCreator(ch) == myUid;
            final member = chMembers(ch)[myUid] == true;
            return ListView(children: [
              const SizedBox(height: 20),
              Center(
                child: GestureDetector(
                  onTap: busy ? null : () => _photoSheet(ch),
                  child: Stack(alignment: Alignment.center, children: [
                    Avatar(url: str(ch['photoUrl']), icon: Icons.campaign, r: 56),
                    if (busy) const CircularProgressIndicator(),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              Center(
                  child: NameRow(
                      name: str(ch['name']),
                      icon: 20,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.w800))),
              const SizedBox(height: 6),
              Center(
                  child: Text('${chMembers(ch).length} pengikut',
                      style: const TextStyle(color: kHint))),
              if (str(ch['description']).isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(str(ch['description']),
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70)),
                ),
              const Divider(height: 1),
              if (creator)
                ListTile(
                  leading: const Icon(Icons.edit_outlined),
                  title: const Text('Edit nama & deskripsi'),
                  onTap: () => _editText(ch),
                ),
              if (!creator)
                ListTile(
                  leading: Icon(member ? Icons.exit_to_app : Icons.add_circle_outline,
                      color: member ? kRed : Colors.white),
                  title: Text(member ? 'Berhenti mengikuti' : 'Ikuti saluran',
                      style: TextStyle(color: member ? kRed : Colors.white)),
                  onTap: () {
                    final r = db.ref('channels/${widget.id}/members/$myUid');
                    member ? r.remove() : r.set(true);
                  },
                ),
              if (creator)
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: kRed),
                  title: const Text('Hapus saluran', style: TextStyle(color: kRed)),
                  onTap: () async {
                    final nav = Navigator.of(context);
                    await db.ref('channels/${widget.id}').remove();
                    nav.popUntil((r) => r.isFirst);
                  },
                ),
            ]);
          },
        ),
      );
}

// ═══════════════════════ NUUR AI CHAT ═══════════════════════
class _AiMsg {
  final String text;
  final bool user;
  final bool error;
  _AiMsg(this.text, this.user, {this.error = false});
}

class NuurAIChatScreen extends StatefulWidget {
  const NuurAIChatScreen({super.key});
  @override
  State<NuurAIChatScreen> createState() => _NuurAIChatScreenState();
}

class _NuurAIChatScreenState extends State<NuurAIChatScreen> {
  final ctl = TextEditingController();
  final msgs = <_AiMsg>[];
  bool sending = false;
  String chatId = DateTime.now().millisecondsSinceEpoch.toString();

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  Future<void> _send([String? preset]) async {
    final t = (preset ?? ctl.text).trim();
    if (t.isEmpty || sending) return;
    ctl.clear();
    setState(() {
      msgs.add(_AiMsg(t, true));
      sending = true;
    });
    try {
      final r = await NuurAI.chat(t, chatId);
      if (mounted) setState(() => msgs.add(_AiMsg(r, false)));
    } catch (e) {
      final m = e.toString().replaceFirst('Exception: ', '');
      if (mounted) {
        setState(() => msgs.add(_AiMsg(
            m.contains('TimeoutException') ? 'Koneksi ke AI timeout, coba lagi.' : 'Gagal: $m',
            false,
            error: true)));
      }
    }
    if (mounted) setState(() => sending = false);
  }

  void _clear() {
    setState(() {
      msgs.clear();
      sending = false;
      chatId = DateTime.now().millisecondsSinceEpoch.toString();
    });
  }

  Widget _aiRow(Widget bubble) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          const AiAvatar(r: 13),
          const SizedBox(width: 8),
          Flexible(child: bubble),
          const SizedBox(width: 40),
        ]),
      );

  Widget _item(int i) {
    if (sending && i == 0) {
      return _aiRow(Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(18)),
        child: const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
      ));
    }
    final m = msgs[msgs.length - 1 - (i - (sending ? 1 : 0))];
    if (m.user) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Align(
          alignment: Alignment.centerRight,
          child: Container(
            constraints:
                BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: SelectableText(m.text,
                style: const TextStyle(color: Colors.black, fontSize: 15.5)),
          ),
        ),
      );
    }
    return _aiRow(Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
          color: m.error ? const Color(0xFFB3261E) : kCard,
          borderRadius: BorderRadius.circular(18)),
      child: m.error
          ? Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.error_outline, size: 18),
              const SizedBox(width: 8),
              Flexible(child: Text(m.text, style: const TextStyle(color: Colors.white))),
            ])
          : SelectableText(m.text,
              style: const TextStyle(color: Colors.white, fontSize: 15.5)),
    ));
  }

  Widget _empty(String name) => Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const AiAvatar(r: 44),
            const SizedBox(height: 16),
            Text('Halo, saya $name',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Tanyakan apa saja. Saya siap membantu.',
                style: TextStyle(color: kHint)),
            const SizedBox(height: 20),
            Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
              for (final q in [
                'Buatkan ide caption bisnis',
                'Jelaskan apa itu AI',
                'Tulis pesan sapaan pelanggan',
              ])
                ActionChip(
                  backgroundColor: kCard,
                  side: const BorderSide(color: kLine),
                  label: Text(q, style: const TextStyle(color: Colors.white)),
                  onPressed: () => _send(q),
                ),
            ]),
          ]),
        ),
      );

  Widget _input() => Container(
        color: kBg,
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: TextField(
              controller: ctl,
              minLines: 1,
              maxLines: 5,
              textInputAction: TextInputAction.newline,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Tanya NUUR AI...',
                fillColor: kCard,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(22),
                    borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: sending ? null : _send,
            child: CircleAvatar(
              radius: 22,
              backgroundColor: sending ? kLine : Colors.white,
              child: Icon(Icons.arrow_upward,
                  color: sending ? kHint : Colors.black),
            ),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => DbValue(
        path: 'app_config/nuur_ai',
        builder: (c, v, _) {
          final cfg = asMap(v);
          final enabled = cfg['enabled'] != false;
          final name = str(cfg['name']).isEmpty ? kAiName : str(cfg['name']);
          return Scaffold(
            appBar: AppBar(
              titleSpacing: 12,
              title: Row(children: [
                const AiAvatar(r: 18),
                const SizedBox(width: 10),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const NameRow(
                      name: 'NUUR AI',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  Row(children: [
                    Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                            color: enabled ? Colors.white : kHint,
                            shape: BoxShape.circle)),
                    const SizedBox(width: 5),
                    Text(enabled ? 'Online' : 'Maintenance',
                        style: const TextStyle(fontSize: 12, color: kHint)),
                  ]),
                ]),
              ]),
              actions: [
                IconButton(
                  tooltip: 'Hapus chat',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: msgs.isEmpty && !sending ? null : _clear,
                ),
              ],
            ),
            body: !enabled
                ? const Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.build_circle_outlined, size: 64, color: kHint),
                      SizedBox(height: 14),
                      Text('AI sedang maintenance',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w700)),
                      SizedBox(height: 6),
                      Text('Silakan coba lagi nanti.',
                          style: TextStyle(color: kHint)),
                    ]),
                  )
                : Column(children: [
                    Expanded(
                      child: msgs.isEmpty && !sending
                          ? _empty(name)
                          : ListView.builder(
                              reverse: true,
                              padding: const EdgeInsets.all(12),
                              itemCount: msgs.length + (sending ? 1 : 0),
                              itemBuilder: (c, i) => _item(i),
                            ),
                    ),
                    SafeArea(top: false, child: _input()),
                  ]),
          );
        },
      );
}

// ═══════════════════════ SETTING ═══════════════════════
class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
        child: Text(t,
            style: const TextStyle(
                color: kHint, fontSize: 12.5, fontWeight: FontWeight.w700)),
      );

  Widget _switch(String title, String key, Map<String, dynamic> priv,
          {bool def = true}) =>
      SwitchListTile(
        title: Text(title),
        value: priv[key] == null ? def : priv[key] == true,
        onChanged: (v) => db.ref('users/$myUid/privacy/$key').set(v),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Setting')),
        body: DbValue(
          path: 'users/$myUid',
          builder: (c, v, loaded) {
            final u = asMap(v);
            if (u.isEmpty) return const Center(child: CircularProgressIndicator());
            final priv = asMap(u['privacy']);
            return ListView(children: [
              InkWell(
                onTap: () => Navigator.push(c,
                    MaterialPageRoute(builder: (_) => EditProfilePage(user: u))),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    Avatar(name: str(u['name']), url: str(u['photoUrl']), r: 34),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            NameRow(
                                name: str(u['name']),
                                verified: u['isVerified'] == true,
                                icon: 18,
                                style: const TextStyle(
                                    fontSize: 19, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 2),
                            Text('@${str(u['username'])}',
                                style: const TextStyle(color: kHint)),
                            Text(str(u['email']),
                                style: const TextStyle(color: kHint, fontSize: 12)),
                          ]),
                    ),
                    const Icon(Icons.chevron_right, color: kHint),
                  ]),
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Edit profil'),
                onTap: () => Navigator.push(c,
                    MaterialPageRoute(builder: (_) => EditProfilePage(user: u))),
              ),
              _section('PRIVASI'),
              _switch('Tampilkan status online', 'showOnline', priv),
              _switch('Tanda dibaca', 'readReceipts', priv),
              _switch('Terakhir dilihat', 'lastSeen', priv),
              if (isAdminUser) ...[
                _section('ADMIN'),
                ListTile(
                  leading: const Icon(Icons.admin_panel_settings_outlined),
                  title: const Text('Admin Panel'),
                  subtitle: const Text('Ban/Unban & Foto profil AI',
                      style: TextStyle(color: kHint)),
                  trailing: const Icon(Icons.chevron_right, color: kHint),
                  onTap: () => Navigator.push(c,
                      MaterialPageRoute(builder: (_) => const AdminPanelPage())),
                ),
              ],
              const SizedBox(height: 16),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.logout, color: kRed),
                title: const Text('Keluar', style: TextStyle(color: kRed)),
                onTap: () => FirebaseAuth.instance.signOut(),
              ),
              const SizedBox(height: 20),
              const Center(
                  child: Text('NUUR COMMUNICATION V7.1',
                      style: TextStyle(color: kHint, fontSize: 12))),
              const SizedBox(height: 20),
            ]);
          },
        ),
      );
}

class EditProfilePage extends StatefulWidget {
  final Map<String, dynamic> user;
  const EditProfilePage({super.key, required this.user});
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final TextEditingController name =
      TextEditingController(text: str(widget.user['name']));
  late final TextEditingController username =
      TextEditingController(text: str(widget.user['username']));
  late String photo = str(widget.user['photoUrl']);
  bool busy = false;

  @override
  void dispose() {
    name.dispose();
    username.dispose();
    super.dispose();
  }

  Future<void> _photo() async {
    final f = await pickImageFile(size: 800);
    if (f == null) return;
    setState(() => busy = true);
    try {
      final url = await uploadFile('profile_photos/$myUid.jpg', f, 'image/jpeg');
      await db.ref('users/$myUid/photoUrl').set(url);
      if (mounted) setState(() => photo = url);
    } catch (e) {
      if (mounted) toast(context, 'Gagal upload: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _save() async {
    final n = name.text.trim();
    final un = username.text.trim().replaceAll('@', '').toLowerCase();
    if (n.isEmpty || un.isEmpty) {
      toast(context, 'Nama dan username wajib diisi');
      return;
    }
    setState(() => busy = true);
    try {
      await db
          .ref('users/$myUid')
          .update(<String, Object?>{'name': n, 'username': un});
      await FirebaseAuth.instance.currentUser?.updateDisplayName(n);
      if (mounted) {
        toast(context, 'Profil disimpan');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        setState(() => busy = false);
        toast(context, 'Gagal: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Edit Profil'),
          actions: [
            TextButton(
                onPressed: busy ? null : _save,
                child: const Text('Simpan',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          ],
        ),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Center(
            child: GestureDetector(
              onTap: busy ? null : _photo,
              child: Stack(alignment: Alignment.center, children: [
                Avatar(name: name.text, url: photo, r: 52),
                if (busy) const CircularProgressIndicator(),
              ]),
            ),
          ),
          TextButton(
              onPressed: busy ? null : _photo, child: const Text('Ganti foto profil')),
          const SizedBox(height: 10),
          TextField(
              controller: name,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Nama')),
          const SizedBox(height: 12),
          TextField(
              controller: username,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(hintText: 'Username')),
        ]),
      );
}

// ═══════════════════════ ADMIN PANEL ═══════════════════════
class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});
  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  final nameCtl = TextEditingController();
  bool nameLoaded = false, busy = false;
  String q = '';

  @override
  void dispose() {
    nameCtl.dispose();
    super.dispose();
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
        child: Text(t,
            style: const TextStyle(
                color: kHint, fontSize: 12.5, fontWeight: FontWeight.w800)),
      );

  Future<void> _changePhoto() async {
    final f = await pickImageFile(size: 1024);
    if (f == null) return;
    setState(() => busy = true);
    try {
      final url = await uploadFile('ai_profile/ai_avatar.jpg', f, 'image/jpeg');
      final n = nameCtl.text.trim().isEmpty ? kAiName : nameCtl.text.trim();
      await db.ref('app_config/nuur_ai').update(<String, Object?>{
        'photoUrl': url,
        'name': n,
        'updatedAt': ServerValue.timestamp,
      });
      if (mounted) toast(context, 'Foto AI berhasil diupdate');
    } catch (e) {
      if (mounted) toast(context, 'Gagal upload: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _saveName() async {
    final n = nameCtl.text.trim();
    if (n.isEmpty) {
      toast(context, 'Nama AI tidak boleh kosong');
      return;
    }
    try {
      await db.ref('app_config/nuur_ai').update(
          <String, Object?>{'name': n, 'updatedAt': ServerValue.timestamp});
      if (mounted) toast(context, 'Nama AI disimpan');
    } catch (e) {
      if (mounted) toast(context, 'Gagal: $e');
    }
  }

  Widget _aiCard() => DbValue(
        path: 'app_config/nuur_ai',
        builder: (c, v, loaded) {
          final cfg = asMap(v);
          if (loaded && !nameLoaded) {
            nameLoaded = true;
            nameCtl.text = str(cfg['name']).isEmpty ? kAiName : str(cfg['name']);
          }
          final enabled = cfg['enabled'] != false;
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: kCard, borderRadius: BorderRadius.circular(16)),
            child: Column(children: [
              Stack(alignment: Alignment.center, children: [
                Avatar(url: str(cfg['photoUrl']), icon: Icons.smart_toy, r: 40),
                if (busy) const CircularProgressIndicator(),
              ]),
              const SizedBox(height: 12),
              Text(kAiName,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Row(mainAxisSize: MainAxisSize.min, children: [
                Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                        color: enabled ? Colors.white : kHint,
                        shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text(enabled ? 'Online' : 'Maintenance',
                    style: const TextStyle(color: kHint)),
              ]),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                  onPressed: busy ? null : _changePhoto,
                  icon: const Icon(Icons.photo_camera_outlined),
                  label: const Text('Ganti Foto Profile AI',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: nameCtl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Nama AI',
                  fillColor: kBg,
                  suffixIcon: IconButton(
                      icon: const Icon(Icons.check), onPressed: _saveName),
                ),
              ),
              const SizedBox(height: 6),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Aktifkan NUUR AI'),
                subtitle: const Text('Jika mati, user melihat "AI sedang maintenance"',
                    style: TextStyle(color: kHint, fontSize: 12)),
                value: enabled,
                onChanged: (val) =>
                    db.ref('app_config/nuur_ai/enabled').set(val),
              ),
            ]),
          );
        },
      );

  Widget _users() => DbValue(
        path: 'users',
        builder: (c, v, loaded) {
          if (!loaded) {
            return const Padding(
                padding: EdgeInsets.all(20),
                child: Center(child: CircularProgressIndicator()));
          }
          final list = mapValues(v)
              .where((u) =>
                  q.isEmpty ||
                  str(u['name']).toLowerCase().contains(q) ||
                  str(u['email']).toLowerCase().contains(q) ||
                  str(u['username']).toLowerCase().contains(q))
              .toList()
            ..sort((a, b) =>
                str(a['name']).toLowerCase().compareTo(str(b['name']).toLowerCase()));
          return Column(children: [
            for (final u in list)
              ListTile(
                leading: Avatar(name: str(u['name']), url: str(u['photoUrl'])),
                title: NameRow(
                    name: str(u['name']),
                    verified: u['isVerified'] == true),
                subtitle: Text(
                    '${str(u['email'])}${u['isBanned'] == true ? '  •  BANNED' : ''}',
                    style: TextStyle(
                        color: u['isBanned'] == true ? kRed : kHint, fontSize: 12)),
                trailing: str(u['email']).toLowerCase() == kAdminEmail ||
                        str(u['uid']) == myUid
                    ? null
                    : OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          foregroundColor:
                              u['isBanned'] == true ? Colors.white : kRed,
                          side: BorderSide(
                              color: u['isBanned'] == true ? Colors.white : kRed),
                        ),
                        onPressed: () => db
                            .ref('users/${str(u['uid'])}/isBanned')
                            .set(u['isBanned'] != true),
                        child: Text(u['isBanned'] == true ? 'UNBAN' : 'BAN'),
                      ),
              ),
          ]);
        },
      );

  @override
  Widget build(BuildContext context) {
    if (!isAdminUser) {
      return Scaffold(
          appBar: AppBar(title: const Text('Admin Panel')),
          body: const Center(
              child: Text('Akses ditolak', style: TextStyle(color: kHint))));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Panel')),
      body: ListView(children: [
        _section('NUUR AI SETTINGS'),
        _aiCard(),
        _section('KELOLA PENGGUNA (BAN / UNBAN)'),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: TextField(
            onChanged: (val) => setState(() => q = val.trim().toLowerCase()),
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search, color: kHint),
                hintText: 'Cari nama / email / username'),
          ),
        ),
        _users(),
        const SizedBox(height: 30),
      ]),
    );
  }
}

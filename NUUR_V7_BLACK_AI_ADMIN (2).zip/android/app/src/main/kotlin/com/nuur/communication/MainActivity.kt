package com.nuur.communication

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

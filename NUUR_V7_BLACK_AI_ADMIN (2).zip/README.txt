NUUR COMMUNICATION V7.1 - Black White + NUUR AI + Admin Upload Foto AI + Foto Saluran
Build: push ke GitHub -> Actions "Build NUUR APK" -> artifact NUUR-APK (app-release.apk)
Firebase Console (wajib, sekali saja):
 1. Realtime Database > Rules: tempel isi database.rules.json
 2. Storage > Rules: tempel isi storage.rules
 3. Authentication > aktifkan Email/Password
 4. Daftar akun dengan email admin@nuur.com untuk akses Admin Panel

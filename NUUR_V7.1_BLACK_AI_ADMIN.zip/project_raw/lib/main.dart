import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';

// ───────────── Konstanta & tema ─────────────
const kBlack = Color(0xFF000000);
const kBar = Color(0xFF121212);
const kCard = Color(0xFF1C1C1E);
const kGrey = Color(0xFF8E8E93);
const kLine = Color(0xFF2C2C2E);
const kBlue = Color(0xFF0A84FF);
const kDbUrl = 'https://voxa-clone-bfbbe-default-rtdb.firebaseio.com';
const kAdminEmail = 'admin@nuur.com';
const kAiName = 'NUUR COMMUNICATION AI';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyBQknHE3NYAOu25YeVbur6e9Qwx8sGWn20',
      appId: '1:996283996536:android:700c0c32f880ae6647108d',
      messagingSenderId: '996283996536',
      projectId: 'voxa-clone-bfbbe',
      databaseURL: kDbUrl,
      storageBucket: 'voxa-clone-bfbbe.firebasestorage.app',
    ),
  );
  runApp(const NuurApp());
}

// ───────────── Helpers ─────────────
FirebaseDatabase get db => FirebaseDatabase.instanceFor(app: Firebase.app(), databaseURL: kDbUrl);
String get myUid => FirebaseAuth.instance.currentUser!.uid;
bool get isAdminUser => FirebaseAuth.instance.currentUser?.email == kAdminEmail;
Map<String, dynamic> asMap(Object? v) =>
    v is Map ? v.map((k, e) => MapEntry(k.toString(), e)) : <String, dynamic>{};
int tsOf(Map m) => m['ts'] is num ? (m['ts'] as num).toInt() : 0;
String s(Object? v) => v?.toString() ?? '';
String hhmm(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts);
  return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}
String mmss(int ms) {
  final t = ms ~/ 1000;
  return '${(t ~/ 60).toString().padLeft(2, '0')}:${(t % 60).toString().padLeft(2, '0')}';
}
void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    backgroundColor: Colors.white, content: Text(m, style: const TextStyle(color: Colors.black))));

Future<String> uploadFile(String path, File f, String type) async {
  final ref = FirebaseStorage.instance.ref(path);
  await ref.putFile(f, SettableMetadata(contentType: type));
  return await ref.getDownloadURL();
}

Map<String, dynamic> newProfile(User u, String name, String username) => {
      'uid': u.uid, 'name': name, 'username': username, 'email': u.email ?? '', 'photoUrl': '',
      'isVerified': true, 'isBusiness': true, 'isBanned': false, 'privacy': false,
      'createdAt': ServerValue.timestamp,
    };

PreferredSizeWidget mkBar({Widget? title, String? text, List<Widget>? actions, PreferredSizeWidget? bottom, bool center = true}) =>
    AppBar(
      backgroundColor: kBar, foregroundColor: Colors.white, elevation: 0, scrolledUnderElevation: 0,
      centerTitle: center, title: title ?? Text(text ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
      actions: actions, bottom: bottom,
    );

InputDecoration inputDec(String hint, {IconData? icon, double radius = 12}) => InputDecoration(
      hintText: hint, hintStyle: const TextStyle(color: kGrey), filled: true, fillColor: kCard,
      prefixIcon: icon == null ? null : Icon(icon, color: Colors.white),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(radius), borderSide: BorderSide.none),
    );

ButtonStyle whiteBtn() => ElevatedButton.styleFrom(
    backgroundColor: Colors.white, foregroundColor: Colors.black,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)));

class MenuItem {
  final String label; final IconData icon; final VoidCallback onTap; final bool red;
  MenuItem(this.label, this.icon, this.onTap, {this.red = false});
}

// Popup iOS: blur + #1C1C1E 80%
void showIosMenu(BuildContext ctx, List<MenuItem> items) {
  if (items.isEmpty) return;
  HapticFeedback.mediumImpact();
  showGeneralDialog(
    context: ctx, barrierDismissible: true, barrierLabel: 'menu', barrierColor: Colors.black45,
    transitionDuration: const Duration(milliseconds: 150),
    pageBuilder: (c, _, __) => Center(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            width: 250, color: const Color(0xCC1C1C1E),
            child: Material(
              color: Colors.transparent,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                for (int i = 0; i < items.length; i++) ...[
                  if (i > 0) const Divider(height: 1, color: kLine),
                  InkWell(
                    onTap: () { Navigator.pop(c); items[i].onTap(); },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                      child: Row(children: [
                        Expanded(child: Text(items[i].label,
                            style: TextStyle(fontSize: 16, color: items[i].red ? Colors.redAccent : Colors.white))),
                        Icon(items[i].icon, size: 20, color: items[i].red ? Colors.redAccent : Colors.white),
                      ]),
                    ),
                  ),
                ],
              ]),
            ),
          ),
        ),
      ),
    ),
  );
}

// ───────────── NUUR AI Service ─────────────
class NuurAI {
  static const _apiKey = 'sylva-8e01ad1bb084e62abfe8783b8712194b';
  static Future<String> chat(String prompt, String chatId) async {
    final uri = Uri.parse('https://sylvatica.my.id/api/ai/chatgpt'
        '?prompt=${Uri.encodeComponent(prompt)}&chat_id=${Uri.encodeComponent(chatId)}'
        '&auth=nuur_user&apikey=$_apiKey');
    final r = await http.get(uri).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
    final j = jsonDecode(r.body);
    dynamic v = j is Map ? (j['reply'] ?? j['result'] ?? j['response'] ?? j['text']) : null;
    if (v is Map) v = v['reply'] ?? v['result'] ?? v['response'] ?? v['text'] ?? jsonEncode(v);
    if (v == null) throw Exception('Respons AI kosong');
    return v.toString();
  }
}

// ───────────── Widget kecil ─────────────
class Avatar extends StatelessWidget {
  final String name; final double r;
  const Avatar({super.key, required this.name, this.r = 26});
  @override
  Widget build(BuildContext context) => CircleAvatar(
      radius: r, backgroundColor: kCard,
      child: Text(name.isEmpty ? '?' : name[0].toUpperCase(),
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: r * .8)));
}

class NameRow extends StatelessWidget {
  final String name; final bool verified; final double icon; final TextStyle? style; final String? tag;
  const NameRow({super.key, required this.name, this.verified = true, this.icon = 16, this.style, this.tag});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Flexible(child: Text(name, style: style ?? const TextStyle(color: Colors.white), overflow: TextOverflow.ellipsis)),
        if (verified) ...[const SizedBox(width: 4), Icon(Icons.verified, color: kBlue, size: icon)],
        if (tag != null) ...[const SizedBox(width: 6), Text(tag!, style: const TextStyle(fontSize: 10.5, color: kGrey))],
      ]);
}

class AiAvatar extends StatelessWidget {
  final double r;
  const AiAvatar({super.key, this.r = 20});
  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: db.ref('app_config/nuur_ai/photoUrl').onValue,
        builder: (c, sn) {
          final u = s(sn.data?.snapshot.value);
          return CircleAvatar(
            radius: r, backgroundColor: kCard,
            backgroundImage: u.isEmpty ? null : NetworkImage(u),
            child: u.isEmpty ? Icon(Icons.smart_toy, color: Colors.white, size: r) : null,
          );
        },
      );
}

class ChannelAvatar extends StatelessWidget {
  final String url; final double r;
  const ChannelAvatar({super.key, required this.url, this.r = 26});
  @override
  Widget build(BuildContext context) => CircleAvatar(
        radius: r, backgroundColor: kCard,
        backgroundImage: url.isEmpty ? null : NetworkImage(url),
        child: url.isEmpty ? Icon(Icons.campaign, color: Colors.white, size: r) : null,
      );
}

// Path Storage selalu sama per saluran -> tambah ?v= supaya cache lama tidak dipakai
String bust(String url) => '$url${url.contains('?') ? '&' : '?'}v=${DateTime.now().millisecondsSinceEpoch}';

class UsersBuilder extends StatelessWidget {
  final Widget Function(BuildContext, Map<String, Map<String, dynamic>>) builder;
  const UsersBuilder({super.key, required this.builder});
  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: db.ref('users').onValue,
        builder: (c, sn) {
          if (sn.hasError) return Center(child: Text('Gagal memuat: ${sn.error}'));
          if (!sn.hasData) return const Center(child: CircularProgressIndicator(color: Colors.white));
          return builder(c, asMap(sn.data!.snapshot.value).map((k, v) => MapEntry(k, asMap(v))));
        },
      );
}

// ───────────── App & Gate ─────────────
class NuurApp extends StatelessWidget {
  const NuurApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NUUR COMMUNICATION', debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark, useMaterial3: false,
          scaffoldBackgroundColor: kBlack, canvasColor: kBlack, dividerColor: kLine,
          colorScheme: const ColorScheme.dark(primary: Colors.white, secondary: Colors.white, surface: kCard),
          iconTheme: const IconThemeData(color: Colors.white),
          textSelectionTheme: const TextSelectionThemeData(cursorColor: Colors.white),
          switchTheme: SwitchThemeData(
            thumbColor: const WidgetStatePropertyAll(Colors.white),
            trackColor: WidgetStateProperty.resolveWith(
                (st) => st.contains(WidgetState.selected) ? const Color(0xFF636366) : kLine),
          ),
        ),
        home: StreamBuilder<User?>(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (c, sn) {
            if (sn.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator(color: Colors.white)));
            }
            if (sn.data == null) return const AuthPage();
            return StreamBuilder<DatabaseEvent>(
              stream: db.ref('users/${sn.data!.uid}/isBanned').onValue,
              builder: (c, b) => b.data?.snapshot.value == true ? const BannedScreen() : const HomePage(),
            );
          },
        ),
      );
}

class BannedScreen extends StatelessWidget {
  const BannedScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.block, color: Colors.redAccent, size: 80),
              const SizedBox(height: 16),
              const Text('Akun Diblokir', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text('Akun kamu telah diblokir oleh admin.', textAlign: TextAlign.center, style: TextStyle(color: kGrey)),
              const SizedBox(height: 24),
              ElevatedButton(style: whiteBtn(), onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Keluar')),
            ]),
          ),
        ),
      );
}

// ───────────── AUTH ─────────────
class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool login = true, busy = false;
  final name = TextEditingController(), user = TextEditingController(), email = TextEditingController(), pass = TextEditingController();

  Future<void> submit() async {
    final e = email.text.trim(), p = pass.text, n = name.text.trim();
    final un = user.text.trim().replaceAll('@', '').toLowerCase();
    if (e.isEmpty || p.length < 6 || (!login && (n.isEmpty || un.isEmpty))) {
      toast(context, 'Lengkapi data (password minimal 6 karakter)');
      return;
    }
    setState(() => busy = true);
    try {
      final auth = FirebaseAuth.instance;
      if (login) {
        await auth.signInWithEmailAndPassword(email: e, password: p);
      } else {
        final cred = await auth.createUserWithEmailAndPassword(email: e, password: p);
        await cred.user!.updateDisplayName(n);
        await db.ref('users/${cred.user!.uid}').set(newProfile(cred.user!, n, un));
      }
    } on FirebaseAuthException catch (ex) {
      if (mounted) toast(context, ex.message ?? ex.code);
    } catch (ex) {
      if (mounted) toast(context, '$ex');
    }
    if (mounted) setState(() => busy = false);
  }

  Widget field(TextEditingController c, String h, IconData i, {bool obscure = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: c, obscureText: obscure, autocorrect: false,
            style: const TextStyle(color: Colors.white), decoration: inputDec(h, icon: i)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                Container(width: 84, height: 84, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                    child: const Icon(Icons.chat_bubble, color: Colors.black, size: 42)),
                const SizedBox(height: 14),
                const Text('NUUR COMMUNICATION', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                const Text('Business Premium', style: TextStyle(color: kGrey)),
                const SizedBox(height: 28),
                if (!login) ...[field(name, 'Nama', Icons.person_outline), field(user, 'Username (@)', Icons.alternate_email)],
                field(email, 'Email', Icons.mail_outline),
                field(pass, 'Password', Icons.lock_outline, obscure: true),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity, height: 50,
                  child: ElevatedButton(
                    style: whiteBtn(), onPressed: busy ? null : submit,
                    child: busy
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                        : Text(login ? 'Masuk' : 'Daftar', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ),
                TextButton(
                    onPressed: () => setState(() => login = !login),
                    child: Text(login ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk', style: const TextStyle(color: Colors.white))),
              ]),
            ),
          ),
        ),
      );
}

// ───────────── HOME (5 TAB) ─────────────
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    _ensure();
  }

  Future<void> _ensure() async {
    try {
      final u = FirebaseAuth.instance.currentUser!;
      final ref = db.ref('users/${u.uid}');
      final snap = await ref.get();
      if (!snap.exists) {
        final n = u.displayName ?? (u.email ?? 'user').split('@').first;
        await ref.set(newProfile(u, n, n.toLowerCase().replaceAll(' ', '')));
      } else if (asMap(snap.value)['isVerified'] != true) {
        await ref.update({'isVerified': true, 'isBusiness': true});
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 5,
        child: Scaffold(
          appBar: mkBar(
            text: 'NUUR COMMUNICATION',
            bottom: const TabBar(
              indicatorColor: Colors.white, labelColor: Colors.white, unselectedLabelColor: kGrey,
              labelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w600), labelPadding: EdgeInsets.zero,
              tabs: [
                Tab(icon: Icon(Icons.chat_bubble_outline, size: 22), text: 'Chat'),
                Tab(icon: Icon(Icons.groups_outlined, size: 22), text: 'Grup'),
                Tab(icon: Icon(Icons.campaign_outlined, size: 22), text: 'Saluran'),
                Tab(icon: Icon(Icons.smart_toy_outlined, size: 22), text: 'NUUR AI'),
                Tab(icon: Icon(Icons.settings_outlined, size: 22), text: 'Setting'),
              ],
            ),
          ),
          body: const TabBarView(
              children: [UsersTab(), GroupsTab(), ChannelsTab(), NuurAIChatScreen(), SettingsTab()]),
        ),
      );
}

// ───────────── TAB CHAT + STATUS 24 JAM ─────────────
class UsersTab extends StatelessWidget {
  const UsersTab({super.key});
  @override
  Widget build(BuildContext context) => Column(children: [
        const StatusBar(),
        const Divider(height: 1),
        Expanded(
          child: UsersBuilder(builder: (c, users) {
            final list = users.values.where((u) => u['uid'] != myUid).toList()
              ..sort((a, b) => s(a['name']).toLowerCase().compareTo(s(b['name']).toLowerCase()));
            if (list.isEmpty) return const Center(child: Text('Belum ada pengguna lain', style: TextStyle(color: kGrey)));
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
              itemBuilder: (c, i) {
                final u = list[i];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: Avatar(name: s(u['name'])),
                  title: NameRow(name: s(u['name']), verified: u['isVerified'] == true,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  subtitle: Text('@${s(u['username'])}', style: const TextStyle(color: kGrey)),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(peer: u))),
                );
              },
            );
          }),
        ),
      ]);
}

class StatusBar extends StatelessWidget {
  const StatusBar({super.key});

  Widget tile(String name, bool has, VoidCallback onTap, {bool plus = false}) => GestureDetector(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.only(right: 14),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: has ? Colors.white : kLine, width: 2)),
              child: plus
                  ? const CircleAvatar(radius: 24, backgroundColor: kCard, child: Icon(Icons.add, color: Colors.white))
                  : Avatar(name: name, r: 24),
            ),
            const SizedBox(height: 4),
            SizedBox(width: 60, child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11))),
          ]),
        ),
      );

  Future<void> _photo(BuildContext c) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1600);
    if (x == null) return;
    try {
      final ts = DateTime.now().millisecondsSinceEpoch;
      final url = await uploadFile('status/${myUid}_$ts.jpg', File(x.path), 'image/jpeg');
      await db.ref('status/$myUid').set({'name': FirebaseAuth.instance.currentUser?.displayName ?? '', 'type': 'image', 'url': url, 'ts': ServerValue.timestamp});
    } catch (e) {
      if (c.mounted) toast(c, 'Gagal: $e');
    }
  }

  Future<void> _text(BuildContext c) async {
    final t = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (d) => AlertDialog(
        backgroundColor: kCard, title: const Text('Status teks'),
        content: TextField(controller: t, maxLines: 3, decoration: inputDec('Tulis status')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal', style: TextStyle(color: kGrey))),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Posting')),
        ],
      ),
    );
    if (ok != true || t.text.trim().isEmpty) return;
    await db.ref('status/$myUid').set({'name': FirebaseAuth.instance.currentUser?.displayName ?? '', 'type': 'text', 'text': t.text.trim(), 'ts': ServerValue.timestamp});
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: db.ref('status').onValue,
        builder: (c, sn) {
          final now = DateTime.now().millisecondsSinceEpoch;
          final all = asMap(sn.data?.snapshot.value).map((k, v) => MapEntry(k, asMap(v)));
          all.removeWhere((k, v) => now - tsOf(v) > 86400000);
          final mine = all[myUid];
          void view(Map<String, dynamic> st) => Navigator.push(c, MaterialPageRoute(builder: (_) => StatusViewPage(st: st)));
          return SizedBox(
            height: 96,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.fromLTRB(16, 10, 0, 6), children: [
              tile('Status Saya', mine != null, () => showIosMenu(c, [
                    MenuItem('Foto status', Icons.photo_outlined, () => _photo(c)),
                    MenuItem('Status teks', Icons.text_fields, () => _text(c)),
                    if (mine != null) MenuItem('Lihat status', Icons.visibility_outlined, () => view(mine)),
                    if (mine != null) MenuItem('Hapus status', Icons.delete_outline, () => db.ref('status/$myUid').remove(), red: true),
                  ]), plus: mine == null),
              ...all.entries.where((e) => e.key != myUid).map((e) => tile(s(e.value['name']), true, () => view(e.value))),
            ]),
          );
        },
      );
}

class StatusViewPage extends StatefulWidget {
  final Map<String, dynamic> st;
  const StatusViewPage({super.key, required this.st});
  @override
  State<StatusViewPage> createState() => _StatusViewPageState();
}

class _StatusViewPageState extends State<StatusViewPage> {
  Timer? t;
  @override
  void initState() {
    super.initState();
    t = Timer(const Duration(seconds: 7), () { if (mounted) Navigator.pop(context); });
  }
  @override
  void dispose() { t?.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final st = widget.st;
    return Scaffold(
      body: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Stack(children: [
          Center(
            child: s(st['type']) == 'image'
                ? Image.network(s(st['url']), fit: BoxFit.contain)
                : Padding(padding: const EdgeInsets.all(28), child: Text(s(st['text']), textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600))),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Avatar(name: s(st['name']), r: 18), const SizedBox(width: 10),
                Text(s(st['name']), style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(width: 8),
                Text(hhmm(tsOf(st)), style: const TextStyle(color: kGrey)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

// ───────────── CHAT 1-1 ─────────────
class ChatPage extends StatelessWidget {
  final Map<String, dynamic> peer;
  const ChatPage({super.key, required this.peer});
  @override
  Widget build(BuildContext context) {
    final ids = [myUid, s(peer['uid'])]..sort();
    return Scaffold(
      appBar: mkBar(
        center: false,
        title: Row(children: [
          Avatar(name: s(peer['name']), r: 18), const SizedBox(width: 10),
          Flexible(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NameRow(name: s(peer['name']), verified: peer['isVerified'] == true, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              Text('@${s(peer['username'])}', style: const TextStyle(fontSize: 12, color: kGrey)),
            ]),
          ),
        ]),
      ),
      body: MessageThread(base: 'chats/${ids.join('_')}', peerUid: s(peer['uid'])),
    );
  }
}

// ───────────── THREAD PESAN (chat/grup/saluran): text, foto, video, stiker, VN ─────────────
const kStickers = ['😀','😂','🥰','😎','🤩','😭','😡','👍','👎','🙏','🔥','💯','❤️','💔','🎉','👏','🤝','💪','🙌','😴','🤔','😱','🥳','☕','🌹','⭐','🚀','🤖','👑','✅','❌','🎁'];

class MessageThread extends StatefulWidget {
  final String base; final bool canSend, showSender; final String? peerUid; final Set<String> admins; final Widget? readOnly;
  const MessageThread({super.key, required this.base, this.canSend = true, this.showSender = false, this.peerUid, this.admins = const {}, this.readOnly});
  @override
  State<MessageThread> createState() => _MessageThreadState();
}

class _MessageThreadState extends State<MessageThread> {
  final ctl = TextEditingController();
  final _rec = AudioRecorder();
  final _sw = Stopwatch();
  Timer? _timer;
  bool recording = false, busy = false;
  String? _recPath;
  List<double> amps = [];

  @override
  void initState() {
    super.initState();
    ctl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _rec.dispose();
    ctl.dispose();
    super.dispose();
  }

  String get _mediaDir => 'chat_media/${widget.base.replaceAll('/', '_')}';

  Future<void> push(Map<String, dynamic> data) async {
    final u = FirebaseAuth.instance.currentUser!;
    await db.ref('${widget.base}/messages').push().set({'senderId': u.uid, 'senderName': u.displayName ?? '', 'ts': ServerValue.timestamp, ...data});
  }

  Future<void> _sendText() async {
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    ctl.clear();
    try { await push({'type': 'text', 'text': t}); } catch (e) { if (mounted) toast(context, 'Gagal kirim: $e'); }
  }

  Future<void> _media(bool video) async {
    final pk = ImagePicker();
    final x = video ? await pk.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 3))
                    : await pk.pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1600);
    if (x == null) return;
    setState(() => busy = true);
    try {
      final ts = DateTime.now().millisecondsSinceEpoch;
      final url = await uploadFile('$_mediaDir/$ts.${video ? 'mp4' : 'jpg'}', File(x.path), video ? 'video/mp4' : 'image/jpeg');
      await push({'type': video ? 'video' : 'image', 'url': url});
    } catch (e) {
      if (mounted) toast(context, 'Upload gagal: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  void _stickers() => showModalBottomSheet(
        context: context, backgroundColor: kCard,
        builder: (c) => SizedBox(
          height: 300,
          child: GridView.count(
            crossAxisCount: 5, padding: const EdgeInsets.all(12),
            children: kStickers.map((e) => InkWell(
                  onTap: () { Navigator.pop(c); push({'type': 'sticker', 'text': e}); },
                  child: Center(child: Text(e, style: const TextStyle(fontSize: 38))),
                )).toList(),
          ),
        ),
      );

  Future<void> _startRec() async {
    if (!await _rec.hasPermission()) { if (mounted) toast(context, 'Izin mikrofon ditolak'); return; }
    final p = '${Directory.systemTemp.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: p);
    _recPath = p; amps = []; _sw..reset()..start();
    setState(() => recording = true);
    _timer = Timer.periodic(const Duration(milliseconds: 150), (_) async {
      final a = await _rec.getAmplitude();
      amps.add(((a.current + 55) / 55).clamp(0.08, 1.0).toDouble());
      if (amps.length > 32) amps.removeAt(0);
      if (mounted) setState(() {});
    });
  }

  Future<void> _stopRec(bool send) async {
    _timer?.cancel();
    _sw.stop();
    final ms = _sw.elapsedMilliseconds;
    final p = await _rec.stop();
    setState(() { recording = false; busy = send; });
    if (!send || p == null || ms < 700) { if (mounted) setState(() => busy = false); return; }
    try {
      final url = await uploadFile('$_mediaDir/${DateTime.now().millisecondsSinceEpoch}.m4a', File(p), 'audio/mp4');
      await push({'type': 'voice', 'url': url, 'dur': ms});
    } catch (e) {
      if (mounted) toast(context, 'Gagal kirim VN: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  void _menu(Map<String, dynamic> m, bool mine) => showIosMenu(context, [
        if (s(m['type']) == 'text') MenuItem('Salin', Icons.copy, () => Clipboard.setData(ClipboardData(text: s(m['text'])))),
        if (mine || widget.admins.contains(myUid))
          MenuItem('Hapus', Icons.delete_outline, () => db.ref('${widget.base}/messages/${m['key']}').remove(), red: true),
      ]);

  Widget _composer() {
    if (recording) {
      return Row(children: [
        IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _stopRec(false)),
        const Icon(Icons.fiber_manual_record, color: Colors.redAccent, size: 14),
        const SizedBox(width: 6),
        Text(mmss(_sw.elapsedMilliseconds)),
        const SizedBox(width: 10),
        Expanded(
          child: SizedBox(
            height: 32,
            child: Row(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.center, children: [
              for (final a in amps)
                Container(margin: const EdgeInsets.symmetric(horizontal: 1), width: 3, height: 4 + 26 * a,
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(2))),
            ]),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(onTap: () => _stopRec(true),
            child: const CircleAvatar(radius: 20, backgroundColor: Colors.white, child: Icon(Icons.arrow_upward, color: Colors.black))),
      ]);
    }
    final hasText = ctl.text.trim().isNotEmpty;
    return Row(children: [
      IconButton(
        icon: const Icon(Icons.add_circle_outline),
        onPressed: () => showIosMenu(context, [
          MenuItem('Foto', Icons.photo_outlined, () => _media(false)),
          MenuItem('Video', Icons.videocam_outlined, () => _media(true)),
          MenuItem('Stiker', Icons.emoji_emotions_outlined, _stickers),
        ]),
      ),
      Expanded(
        child: TextField(
          controller: ctl, minLines: 1, maxLines: 5, textCapitalization: TextCapitalization.sentences,
          style: const TextStyle(color: Colors.white), decoration: inputDec('Pesan', radius: 22),
        ),
      ),
      const SizedBox(width: 8),
      GestureDetector(
        onTap: hasText ? _sendText : _startRec,
        child: CircleAvatar(radius: 20, backgroundColor: Colors.white,
            child: Icon(hasText ? Icons.arrow_upward : Icons.mic, color: Colors.black)),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        child: StreamBuilder<DatabaseEvent>(
          stream: db.ref('${widget.base}/messages').onValue,
          builder: (c, sn) {
            if (sn.hasError) return Center(child: Text('Gagal memuat: ${sn.error}'));
            if (!sn.hasData) return const Center(child: CircularProgressIndicator(color: Colors.white));
            final msgs = asMap(sn.data!.snapshot.value).entries.map((e) {
              final m = asMap(e.value);
              m['key'] = e.key;
              return m;
            }).toList()
              ..sort((a, b) => tsOf(b).compareTo(tsOf(a)));
            if (msgs.isEmpty) return const Center(child: Text('Belum ada pesan', style: TextStyle(color: kGrey)));
            if (widget.peerUid != null) {
              WidgetsBinding.instance.addPostFrameCallback((_) => db.ref('${widget.base}/reads/$myUid').set(ServerValue.timestamp));
            }
            Widget list(int peerRead) => ListView.builder(
                  reverse: true, padding: const EdgeInsets.all(12), itemCount: msgs.length,
                  itemBuilder: (c, i) {
                    final m = msgs[i];
                    final mine = m['senderId'] == myUid;
                    return Bubble(m: m, mine: mine, showSender: widget.showSender, isAdmin: widget.admins.contains(m['senderId']),
                        read: tsOf(m) <= peerRead, onLong: () => _menu(m, mine));
                  },
                );
            if (widget.peerUid == null) return list(0);
            return StreamBuilder<DatabaseEvent>(
              stream: db.ref('${widget.base}/reads/${widget.peerUid}').onValue,
              builder: (c, r) {
                final v = r.data?.snapshot.value;
                return list(v is num ? v.toInt() : 0);
              },
            );
          },
        ),
      ),
      if (busy) const LinearProgressIndicator(minHeight: 2, color: Colors.white, backgroundColor: kLine),
      if (widget.canSend)
        SafeArea(
          child: Container(
            padding: const EdgeInsets.fromLTRB(4, 8, 8, 8),
            decoration: const BoxDecoration(color: kBar, border: Border(top: BorderSide(color: kLine))),
            child: _composer(),
          ),
        )
      else if (widget.readOnly != null)
        widget.readOnly!,
    ]);
  }
}

class Bubble extends StatelessWidget {
  final Map<String, dynamic> m; final bool mine, showSender, isAdmin, read; final VoidCallback onLong;
  const Bubble({super.key, required this.m, required this.mine, required this.showSender, required this.isAdmin, required this.read, required this.onLong});

  @override
  Widget build(BuildContext context) {
    final type = s(m['type']).isEmpty ? 'text' : s(m['type']);
    final fg = mine ? Colors.black : Colors.white;
    final timeColor = mine ? Colors.black45 : kGrey;
    final sender = (showSender && !mine)
        ? Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: NameRow(name: s(m['senderName']), icon: 13, tag: isAdmin ? 'admin' : null,
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: Colors.white)))
        : const SizedBox.shrink();
    final time = Align(
      alignment: Alignment.centerRight,
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(hhmm(tsOf(m)), style: TextStyle(fontSize: 11, color: timeColor)),
        if (mine) ...[const SizedBox(width: 4), Icon(Icons.done_all, size: 15, color: read ? kBlue : kGrey)],
      ]),
    );

    Widget content;
    if (type == 'sticker') {
      content = Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
        if (showSender && !mine) Align(alignment: Alignment.centerLeft, child: sender),
        SizedBox(width: 120, height: 120, child: Center(child: Text(s(m['text']), style: const TextStyle(fontSize: 80)))),
        Text(hhmm(tsOf(m)), style: const TextStyle(fontSize: 11, color: kGrey)),
      ]);
      return Align(
          alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
          child: GestureDetector(onLongPress: onLong, child: Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: content)));
    }
    Widget body;
    if (type == 'image') {
      body = GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ImageViewPage(url: s(m['url'])))),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network(s(m['url']), width: 220, fit: BoxFit.cover,
              loadingBuilder: (c, w, p) => p == null ? w : SizedBox(width: 220, height: 160, child: Center(child: CircularProgressIndicator(color: fg, strokeWidth: 2))),
              errorBuilder: (c, e, st) => SizedBox(width: 220, height: 80, child: Icon(Icons.broken_image, color: fg))),
        ),
      );
    } else if (type == 'video') {
      body = GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(url: s(m['url'])))),
        child: Container(
          width: 220, height: 140,
          decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(12), border: Border.all(color: kLine)),
          child: const Icon(Icons.play_circle_fill, color: Colors.white, size: 56),
        ),
      );
    } else if (type == 'voice') {
      body = VoiceBubble(url: s(m['url']), ms: m['dur'] is num ? (m['dur'] as num).toInt() : 0, color: fg);
    } else {
      body = Text(s(m['text']), style: TextStyle(fontSize: 16, color: fg));
    }
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: onLong,
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
          margin: const EdgeInsets.symmetric(vertical: 2),
          padding: const EdgeInsets.fromLTRB(12, 7, 10, 5),
          decoration: BoxDecoration(
            color: mine ? Colors.white : kCard,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
              bottomLeft: Radius.circular(mine ? 18 : 4), bottomRight: Radius.circular(mine ? 4 : 18)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min,
              children: [sender, body, const SizedBox(height: 2), time]),
        ),
      ),
    );
  }
}

class VoiceBubble extends StatefulWidget {
  final String url; final int ms; final Color color;
  const VoiceBubble({super.key, required this.url, required this.ms, required this.color});
  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  final _p = AudioPlayer();
  bool playing = false;
  double prog = 0;
  late final List<double> bars;
  StreamSubscription? _a, _b;

  @override
  void initState() {
    super.initState();
    final r = math.Random(widget.url.hashCode);
    bars = List.generate(28, (_) => .25 + r.nextDouble() * .75);
    _a = _p.onPlayerComplete.listen((_) { if (mounted) setState(() { playing = false; prog = 0; }); });
    _b = _p.onPositionChanged.listen((d) {
      if (mounted && widget.ms > 0) setState(() => prog = (d.inMilliseconds / widget.ms).clamp(0.0, 1.0).toDouble());
    });
  }

  @override
  void dispose() { _a?.cancel(); _b?.cancel(); _p.dispose(); super.dispose(); }

  Future<void> _toggle() async {
    if (playing) { await _p.pause(); setState(() => playing = false); }
    else { await _p.play(UrlSource(widget.url)); setState(() => playing = true); }
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 210,
        child: Row(children: [
          GestureDetector(onTap: _toggle, child: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_filled, color: widget.color, size: 34)),
          const SizedBox(width: 8),
          Expanded(
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.center, children: [
              for (int i = 0; i < bars.length; i++)
                Container(width: 3, height: 26 * bars[i],
                    decoration: BoxDecoration(color: i / bars.length < prog ? widget.color : widget.color.withValues(alpha: .4), borderRadius: BorderRadius.circular(2))),
            ]),
          ),
          const SizedBox(width: 8),
          Text(mmss(widget.ms), style: TextStyle(fontSize: 11, color: widget.color)),
        ]),
      );
}

class ImageViewPage extends StatelessWidget {
  final String url;
  const ImageViewPage({super.key, required this.url});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: mkBar(text: ''), body: Center(child: InteractiveViewer(child: Image.network(url))));
}

class VideoPage extends StatefulWidget {
  final String url;
  const VideoPage({super.key, required this.url});
  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late final VideoPlayerController c;
  bool ready = false;
  @override
  void initState() {
    super.initState();
    c = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) { if (mounted) { setState(() => ready = true); c.play(); } });
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: mkBar(text: ''),
        body: Center(
          child: ready
              ? GestureDetector(
                  onTap: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
                  child: Stack(alignment: Alignment.center, children: [
                    AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
                    if (!c.value.isPlaying) const Icon(Icons.play_circle_fill, size: 72, color: Colors.white),
                  ]),
                )
              : const CircularProgressIndicator(color: Colors.white),
        ),
      );
}

// ───────────── GRUP ─────────────
class GroupsTab extends StatelessWidget {
  const GroupsTab({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.white,
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateGroupPage())),
          child: const Icon(Icons.group_add, color: Colors.black),
        ),
        body: StreamBuilder<DatabaseEvent>(
          stream: db.ref('groups').onValue,
          builder: (c, sn) {
            if (sn.hasError) return Center(child: Text('Gagal memuat: ${sn.error}'));
            if (!sn.hasData) return const Center(child: CircularProgressIndicator(color: Colors.white));
            final list = asMap(sn.data!.snapshot.value).values.map(asMap).where((g) => asMap(g['members'])[myUid] == true).toList()
              ..sort((a, b) => s(a['name']).toLowerCase().compareTo(s(b['name']).toLowerCase()));
            if (list.isEmpty) return const Center(child: Text('Belum ada grup. Ketuk + untuk membuat.', style: TextStyle(color: kGrey)));
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
              itemBuilder: (c, i) {
                final g = list[i];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: const CircleAvatar(radius: 26, backgroundColor: kCard, child: Icon(Icons.groups)),
                  title: NameRow(name: s(g['name']), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  subtitle: Text('${asMap(g['members']).length} anggota', style: const TextStyle(color: kGrey)),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => GroupChatPage(id: s(g['id'])))),
                );
              },
            );
          },
        ),
      );
}

class CreateGroupPage extends StatefulWidget {
  const CreateGroupPage({super.key});
  @override
  State<CreateGroupPage> createState() => _CreateGroupPageState();
}

class _CreateGroupPageState extends State<CreateGroupPage> {
  final name = TextEditingController();
  final sel = <String>{};
  bool busy = false;

  Future<void> create() async {
    final n = name.text.trim();
    if (n.isEmpty) { toast(context, 'Isi nama grup'); return; }
    setState(() => busy = true);
    try {
      final ref = db.ref('groups').push();
      await ref.set({
        'id': ref.key, 'name': n, 'adminId': myUid, 'admins': {myUid: true},
        'members': {myUid: true, for (final id in sel) id: true}, 'createdAt': ServerValue.timestamp,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) { setState(() => busy = false); toast(context, 'Gagal: $e'); }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: mkBar(text: 'Grup Baru', actions: [TextButton(onPressed: busy ? null : create, child: const Text('Buat', style: TextStyle(color: Colors.white, fontSize: 16)))]),
        body: Column(children: [
          Padding(padding: const EdgeInsets.all(12), child: TextField(controller: name, style: const TextStyle(color: Colors.white), decoration: inputDec('Nama grup'))),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Align(alignment: Alignment.centerLeft, child: Text('Undang anggota', style: TextStyle(color: kGrey)))),
          Expanded(
            child: UsersBuilder(builder: (c, users) => ListView(
                  children: users.values.where((u) => u['uid'] != myUid).map((u) {
                    final id = s(u['uid']);
                    return CheckboxListTile(
                      activeColor: Colors.white, checkColor: Colors.black, value: sel.contains(id),
                      onChanged: (v) => setState(() => v == true ? sel.add(id) : sel.remove(id)),
                      secondary: Avatar(name: s(u['name'])),
                      title: NameRow(name: s(u['name']), verified: u['isVerified'] == true),
                      subtitle: Text('@${s(u['username'])}', style: const TextStyle(color: kGrey)),
                    );
                  }).toList(),
                )),
          ),
        ]),
      );
}

class GroupChatPage extends StatelessWidget {
  final String id;
  const GroupChatPage({super.key, required this.id});
  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: db.ref('groups/$id').onValue,
        builder: (c, sn) {
          final g = asMap(sn.data?.snapshot.value);
          if (g.isEmpty) return Scaffold(appBar: mkBar(text: ''), body: const Center(child: CircularProgressIndicator(color: Colors.white)));
          return Scaffold(
            appBar: mkBar(
              title: InkWell(
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => GroupInfoPage(id: id))),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  NameRow(name: s(g['name']), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  Text('${asMap(g['members']).length} anggota', style: const TextStyle(fontSize: 12, color: kGrey)),
                ]),
              ),
            ),
            body: MessageThread(base: 'groups/$id', showSender: true, admins: asMap(g['admins']).keys.toSet()),
          );
        },
      );
}

class GroupInfoPage extends StatelessWidget {
  final String id;
  const GroupInfoPage({super.key, required this.id});

  void addMember(BuildContext context, List<String> members, Map<String, Map<String, dynamic>> users) {
    final cand = users.values.where((u) => !members.contains(s(u['uid']))).toList();
    showDialog(
      context: context,
      builder: (d) => AlertDialog(
        backgroundColor: kCard, title: const Text('Tambah anggota'),
        content: SizedBox(
          width: double.maxFinite, height: 300,
          child: cand.isEmpty
              ? const Center(child: Text('Semua pengguna sudah masuk'))
              : ListView(children: cand.map((u) => ListTile(
                        leading: Avatar(name: s(u['name']), r: 18), title: NameRow(name: s(u['name'])),
                        subtitle: Text('@${s(u['username'])}', style: const TextStyle(color: kGrey)),
                        onTap: () { db.ref('groups/$id/members/${s(u['uid'])}').set(true); Navigator.pop(d); },
                      )).toList()),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: mkBar(text: 'Info Grup'),
        body: StreamBuilder<DatabaseEvent>(
          stream: db.ref('groups/$id').onValue,
          builder: (c, sn) {
            final g = asMap(sn.data?.snapshot.value);
            if (g.isEmpty) return const Center(child: CircularProgressIndicator(color: Colors.white));
            return UsersBuilder(builder: (c, users) {
              final members = asMap(g['members']).keys.toList();
              final admins = asMap(g['admins']);
              final iAmAdmin = admins[myUid] == true;
              return ListView(children: [
                const SizedBox(height: 20),
                const Center(child: CircleAvatar(radius: 44, backgroundColor: kCard, child: Icon(Icons.groups, size: 44))),
                const SizedBox(height: 12),
                Center(child: NameRow(name: s(g['name']), icon: 22, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700))),
                Center(child: Text('${members.length} anggota', style: const TextStyle(color: kGrey))),
                const SizedBox(height: 16),
                if (iAmAdmin) ListTile(leading: const Icon(Icons.person_add), title: const Text('Tambah anggota'), onTap: () => addMember(c, members, users)),
                ...members.map((uid) {
                  final u = users[uid] ?? <String, dynamic>{};
                  final isAdm = admins[uid] == true;
                  return ListTile(
                    leading: Avatar(name: s(u['name']), r: 20),
                    title: NameRow(name: s(u['name']).isEmpty ? uid : s(u['name'])),
                    subtitle: Text('@${s(u['username'])}', style: const TextStyle(color: kGrey)),
                    trailing: isAdm
                        ? const Text('Admin', style: TextStyle(color: kGrey, fontSize: 12))
                        : (iAmAdmin ? IconButton(icon: const Icon(Icons.remove_circle_outline, color: Colors.redAccent), onPressed: () => db.ref('groups/$id/members/$uid').remove()) : null),
                  );
                }),
                if (!iAmAdmin)
                  TextButton(
                    onPressed: () async {
                      await db.ref('groups/$id/members/$myUid').remove();
                      if (c.mounted) Navigator.popUntil(c, (r) => r.isFirst);
                    },
                    child: const Text('Keluar dari grup', style: TextStyle(color: Colors.redAccent)),
                  ),
              ]);
            });
          },
        ),
      );
}

// ───────────── SALURAN (V7.1: foto saluran) ─────────────
bool isChannelAdmin(Map<String, dynamic> ch) => s(ch['creatorUid']) == myUid || asMap(ch['admins'])[myUid] == true;

class ChannelsTab extends StatelessWidget {
  const ChannelsTab({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.white,
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateChannelPage())),
          child: const Icon(Icons.campaign, color: Colors.black),
        ),
        body: StreamBuilder<DatabaseEvent>(
          stream: db.ref('channels').onValue,
          builder: (c, sn) {
            if (sn.hasError) return Center(child: Text('Gagal memuat: ${sn.error}'));
            if (!sn.hasData) return const Center(child: CircularProgressIndicator(color: Colors.white));
            final list = asMap(sn.data!.snapshot.value).values.map(asMap).toList()
              ..sort((a, b) => s(a['name']).toLowerCase().compareTo(s(b['name']).toLowerCase()));
            if (list.isEmpty) return const Center(child: Text('Belum ada saluran.', style: TextStyle(color: kGrey)));
            return ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
              itemBuilder: (c, i) {
                final ch = list[i];
                final member = asMap(ch['members'])[myUid] == true;
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: ChannelAvatar(url: s(ch['photoUrl']), r: 26),
                  title: NameRow(name: s(ch['name']), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  subtitle: Text(s(ch['description']).isEmpty ? '${asMap(ch['members']).length} anggota' : s(ch['description']),
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: kGrey)),
                  trailing: isChannelAdmin(ch) ? const Text('Admin', style: TextStyle(color: kGrey, fontSize: 12)) : (member ? null : const Text('Ikuti')),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ChannelPage(id: s(ch['id'])))),
                );
              },
            );
          },
        ),
      );
}

class CreateChannelPage extends StatefulWidget {
  const CreateChannelPage({super.key});
  @override
  State<CreateChannelPage> createState() => _CreateChannelPageState();
}

class _CreateChannelPageState extends State<CreateChannelPage> {
  final name = TextEditingController(), desc = TextEditingController();
  File? photo;
  bool busy = false;

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1024);
    if (x != null) setState(() => photo = File(x.path));
  }

  Future<void> _create() async {
    final n = name.text.trim();
    if (n.isEmpty) { toast(context, 'Isi nama saluran'); return; }
    setState(() => busy = true);
    try {
      final ref = db.ref('channels').push();
      final id = ref.key!;
      String url = '';
      if (photo != null) url = bust(await uploadFile('channel_photos/$id.jpg', photo!, 'image/jpeg'));
      await ref.set({
        'id': id, 'name': n, 'description': desc.text.trim(), 'photoUrl': url,
        'creatorUid': myUid, 'admins': {myUid: true}, 'members': {myUid: true},
        'createdAt': ServerValue.timestamp,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) { setState(() => busy = false); toast(context, 'Gagal: $e'); }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: mkBar(text: 'Saluran Baru', actions: [
          TextButton(onPressed: busy ? null : _create, child: const Text('Buat', style: TextStyle(color: Colors.white, fontSize: 16))),
        ]),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Center(
            child: CircleAvatar(
              radius: 40, backgroundColor: kCard,
              backgroundImage: photo == null ? null : FileImage(photo!),
              child: photo == null ? const Icon(Icons.campaign, size: 40, color: Colors.white) : null,
            ),
          ),
          const SizedBox(height: 10),
          Center(child: TextButton(onPressed: busy ? null : _pick, child: const Text('Pilih Foto Channel', style: TextStyle(color: Colors.white)))),
          const SizedBox(height: 10),
          TextField(controller: name, style: const TextStyle(color: Colors.white), decoration: inputDec('Nama Saluran')),
          const SizedBox(height: 12),
          TextField(controller: desc, maxLines: 3, style: const TextStyle(color: Colors.white), decoration: inputDec('Deskripsi')),
          if (busy) const Padding(padding: EdgeInsets.only(top: 20), child: LinearProgressIndicator(color: Colors.white, backgroundColor: kLine)),
        ]),
      );
}

class ChannelPage extends StatelessWidget {
  final String id;
  const ChannelPage({super.key, required this.id});
  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: db.ref('channels/$id').onValue,
        builder: (c, sn) {
          final ch = asMap(sn.data?.snapshot.value);
          if (ch.isEmpty) return Scaffold(appBar: mkBar(text: ''), body: const Center(child: CircularProgressIndicator(color: Colors.white)));
          final isAdmin = isChannelAdmin(ch);
          final follow = asMap(ch['members'])[myUid] == true;
          final fref = db.ref('channels/$id/members/$myUid');
          return Scaffold(
            appBar: mkBar(
              center: false,
              title: InkWell(
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ChannelInfoPage(id: id))),
                child: Row(children: [
                  ChannelAvatar(url: s(ch['photoUrl']), r: 18), const SizedBox(width: 10),
                  Flexible(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      NameRow(name: s(ch['name']), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      Text('${asMap(ch['members']).length} anggota', style: const TextStyle(fontSize: 12, color: kGrey)),
                    ]),
                  ),
                ]),
              ),
              actions: [
                if (!isAdmin)
                  IconButton(icon: Icon(follow ? Icons.notifications_active : Icons.notifications_none), onPressed: () => follow ? fref.remove() : fref.set(true)),
              ],
            ),
            body: MessageThread(
              base: 'channels/$id', canSend: isAdmin, admins: asMap(ch['admins']).keys.toSet(),
              readOnly: SafeArea(
                child: Container(
                  width: double.infinity, padding: const EdgeInsets.all(12), color: kBar,
                  child: follow
                      ? const Text('Hanya admin yang dapat mengirim pesan', textAlign: TextAlign.center, style: TextStyle(color: kGrey))
                      : ElevatedButton(style: whiteBtn(), onPressed: () => fref.set(true), child: const Text('Ikuti Saluran')),
                ),
              ),
            ),
          );
        },
      );
}

class ChannelInfoPage extends StatefulWidget {
  final String id;
  const ChannelInfoPage({super.key, required this.id});
  @override
  State<ChannelInfoPage> createState() => _ChannelInfoPageState();
}

class _ChannelInfoPageState extends State<ChannelInfoPage> {
  bool busy = false;

  Future<void> _change() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1024);
    if (x == null) return;
    setState(() => busy = true);
    try {
      final url = await uploadFile('channel_photos/${widget.id}.jpg', File(x.path), 'image/jpeg');
      await db.ref('channels/${widget.id}/photoUrl').set(bust(url));
      if (mounted) toast(context, 'Foto saluran diperbarui');
    } catch (e) {
      if (mounted) toast(context, 'Gagal upload: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _remove() async {
    setState(() => busy = true);
    try { await FirebaseStorage.instance.ref('channel_photos/${widget.id}.jpg').delete(); } catch (_) {}
    await db.ref('channels/${widget.id}/photoUrl').set('');
    if (mounted) setState(() => busy = false);
  }

  void _photoMenu(Map<String, dynamic> ch) {
    final url = s(ch['photoUrl']);
    final admin = isChannelAdmin(ch);
    showModalBottomSheet(
      context: context, backgroundColor: kCard,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (url.isNotEmpty)
            ListTile(leading: const Icon(Icons.visibility_outlined), title: const Text('Lihat Foto'),
                onTap: () { Navigator.pop(c); Navigator.push(context, MaterialPageRoute(builder: (_) => ImageViewPage(url: url))); }),
          if (admin)
            ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Ganti Foto'), onTap: () { Navigator.pop(c); _change(); }),
          if (admin && url.isNotEmpty)
            ListTile(leading: const Icon(Icons.delete_outline, color: Colors.redAccent), title: const Text('Hapus Foto', style: TextStyle(color: Colors.redAccent)),
                onTap: () { Navigator.pop(c); _remove(); }),
          if (!admin && url.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('Belum ada foto', style: TextStyle(color: kGrey))),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: mkBar(text: 'Info Saluran'),
        body: StreamBuilder<DatabaseEvent>(
          stream: db.ref('channels/${widget.id}').onValue,
          builder: (c, sn) {
            final ch = asMap(sn.data?.snapshot.value);
            if (ch.isEmpty) return const Center(child: CircularProgressIndicator(color: Colors.white));
            final members = asMap(ch['members']).keys.toList();
            final admin = isChannelAdmin(ch);
            final fref = db.ref('channels/${widget.id}/members/$myUid');
            final follow = asMap(ch['members'])[myUid] == true;
            return UsersBuilder(builder: (c, users) => ListView(children: [
                  const SizedBox(height: 20),
                  Center(
                    child: GestureDetector(
                      onTap: busy ? null : () => _photoMenu(ch),
                      child: Stack(alignment: Alignment.center, children: [
                        ChannelAvatar(url: s(ch['photoUrl']), r: 48),
                        if (busy) const CircularProgressIndicator(color: Colors.white),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Center(child: NameRow(name: s(ch['name']), icon: 22, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700))),
                  if (s(ch['description']).isNotEmpty)
                    Padding(padding: const EdgeInsets.fromLTRB(24, 8, 24, 0), child: Text(s(ch['description']), textAlign: TextAlign.center, style: const TextStyle(color: kGrey))),
                  Center(child: Padding(padding: const EdgeInsets.only(top: 6), child: Text('${members.length} anggota', style: const TextStyle(color: kGrey)))),
                  if (!admin)
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: ElevatedButton(style: whiteBtn(), onPressed: () => follow ? fref.remove() : fref.set(true), child: Text(follow ? 'Berhenti Ikuti' : 'Ikuti Saluran')),
                    ),
                  const SizedBox(height: 10),
                  ...members.map((uid) {
                    final u = users[uid] ?? <String, dynamic>{};
                    return ListTile(
                      leading: Avatar(name: s(u['name']), r: 20),
                      title: NameRow(name: s(u['name']).isEmpty ? uid : s(u['name'])),
                      subtitle: Text('@${s(u['username'])}', style: const TextStyle(color: kGrey)),
                      trailing: (s(ch['creatorUid']) == uid || asMap(ch['admins'])[uid] == true) ? const Text('Admin', style: TextStyle(color: kGrey, fontSize: 12)) : null,
                    );
                  }),
                ]));
          },
        ),
      );
}

// ───────────── NUUR AI CHAT ─────────────
class AiMsg {
  final bool user; final String text; final bool error;
  AiMsg(this.user, this.text, {this.error = false});
}

class NuurAIChatScreen extends StatefulWidget {
  const NuurAIChatScreen({super.key});
  @override
  State<NuurAIChatScreen> createState() => _NuurAIChatScreenState();
}

class _NuurAIChatScreenState extends State<NuurAIChatScreen> with AutomaticKeepAliveClientMixin {
  final ctl = TextEditingController();
  final scroll = ScrollController();
  final msgs = <AiMsg>[];
  bool loading = false;
  String chatId = DateTime.now().millisecondsSinceEpoch.toString();

  @override
  bool get wantKeepAlive => true;

  void _down() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  Future<void> _send() async {
    final t = ctl.text.trim();
    if (t.isEmpty || loading) return;
    ctl.clear();
    setState(() { msgs.add(AiMsg(true, t)); loading = true; });
    _down();
    try {
      msgs.add(AiMsg(false, await NuurAI.chat(t, chatId)));
    } catch (e) {
      msgs.add(AiMsg(false, 'Gagal menghubungi NUUR AI: $e', error: true));
    }
    if (mounted) setState(() => loading = false);
    _down();
  }

  Widget _bubble(AiMsg m) {
    final bubble = Container(
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .74),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: m.error ? const Color(0xFFB71C1C) : (m.user ? Colors.white : kCard),
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(m.user ? 18 : 4), bottomRight: Radius.circular(m.user ? 4 : 18)),
      ),
      child: SelectableText(m.text, style: TextStyle(fontSize: 16, color: m.user ? Colors.black : Colors.white)),
    );
    if (m.user) return Align(alignment: Alignment.centerRight, child: Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: bubble));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const AiAvatar(r: 14), const SizedBox(width: 8), Flexible(child: bubble),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return StreamBuilder<DatabaseEvent>(
      stream: db.ref('app_config/nuur_ai').onValue,
      builder: (c, sn) {
        final cfg = asMap(sn.data?.snapshot.value);
        final enabled = cfg['enabled'] != false;
        return Column(children: [
          Container(
            color: kBar, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Row(children: [
              const AiAvatar(r: 20), const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const NameRow(name: 'NUUR AI', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  Text(enabled ? 'Online' : 'Maintenance', style: const TextStyle(fontSize: 12, color: kGrey)),
                ]),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                tooltip: 'Bersihkan chat',
                onPressed: () => setState(() { msgs.clear(); chatId = DateTime.now().millisecondsSinceEpoch.toString(); }),
              ),
            ]),
          ),
          Expanded(
            child: !enabled
                ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.build_circle_outlined, size: 64, color: kGrey), SizedBox(height: 12),
                    Text('AI sedang maintenance', style: TextStyle(fontSize: 16, color: kGrey)),
                  ]))
                : msgs.isEmpty && !loading
                    ? const Center(child: Text('Tanya apa saja ke NUUR AI', style: TextStyle(color: kGrey)))
                    : ListView(
                        controller: scroll, padding: const EdgeInsets.all(12),
                        children: [
                          ...msgs.map(_bubble),
                          if (loading)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Row(children: [
                                const AiAvatar(r: 14), const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(18)),
                                  child: const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                                ),
                              ]),
                            ),
                        ],
                      ),
          ),
          if (enabled)
            Container(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
              decoration: const BoxDecoration(color: kBar, border: Border(top: BorderSide(color: kLine))),
              child: Row(children: [
                Expanded(
                  child: TextField(controller: ctl, minLines: 1, maxLines: 5, style: const TextStyle(color: Colors.white),
                      onSubmitted: (_) => _send(), decoration: inputDec('Tanya NUUR AI...', radius: 22)),
                ),
                const SizedBox(width: 8),
                GestureDetector(onTap: _send, child: const CircleAvatar(radius: 20, backgroundColor: Colors.white, child: Icon(Icons.arrow_upward, color: Colors.black))),
              ]),
            ),
        ]);
      },
    );
  }
}

// ───────────── SETTING ─────────────
class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  Future<void> _edit(BuildContext context, Map<String, dynamic> u) async {
    final n = TextEditingController(text: s(u['name'])), un = TextEditingController(text: s(u['username']));
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        backgroundColor: kCard, title: const Text('Edit Profil'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: inputDec('Nama')), const SizedBox(height: 10),
          TextField(controller: un, decoration: inputDec('Username')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal', style: TextStyle(color: kGrey))),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true || n.text.trim().isEmpty) return;
    await FirebaseAuth.instance.currentUser!.updateDisplayName(n.text.trim());
    await db.ref('users/$myUid').update({'name': n.text.trim(), 'username': un.text.trim().replaceAll('@', '').toLowerCase()});
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<DatabaseEvent>(
        stream: db.ref('users/$myUid').onValue,
        builder: (c, sn) {
          final u = asMap(sn.data?.snapshot.value);
          if (u.isEmpty) return const Center(child: CircularProgressIndicator(color: Colors.white));
          Widget badge(IconData i, String t) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(22)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(i, color: kBlue, size: 22), const SizedBox(width: 6), Text(t, style: const TextStyle(fontWeight: FontWeight.w700))]),
              );
          return ListView(padding: const EdgeInsets.all(16), children: [
            Center(child: Avatar(name: s(u['name']), r: 48)),
            const SizedBox(height: 12),
            Center(child: NameRow(name: s(u['name']), verified: u['isVerified'] == true, icon: 24, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
            Center(child: Text('@${s(u['username'])}', style: const TextStyle(color: kGrey, fontSize: 15))),
            Center(child: Text(s(u['email']), style: const TextStyle(color: kGrey, fontSize: 13))),
            const SizedBox(height: 14),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              if (u['isBusiness'] == true) badge(Icons.business_center, 'Business'),
              const SizedBox(width: 10),
              if (u['isVerified'] == true) badge(Icons.verified, 'Verified'),
            ]),
            const SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(12)),
              child: Column(children: [
                ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Edit Profil'), trailing: const Icon(Icons.chevron_right, color: kGrey), onTap: () => _edit(c, u)),
                const Divider(height: 1),
                SwitchListTile(
                  secondary: const Icon(Icons.lock_outline), title: const Text('Privasi'),
                  subtitle: const Text('Akun privat', style: TextStyle(color: kGrey)),
                  value: u['privacy'] == true, onChanged: (v) => db.ref('users/$myUid/privacy').set(v),
                ),
                if (isAdminUser) ...[
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.admin_panel_settings_outlined), title: const Text('Admin Panel'),
                    trailing: const Icon(Icons.chevron_right, color: kGrey),
                    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AdminPanelPage())),
                  ),
                ],
              ]),
            ),
            const SizedBox(height: 16),
            TextButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Keluar', style: TextStyle(color: Colors.redAccent, fontSize: 16))),
          ]);
        },
      );
}

// ───────────── ADMIN PANEL (hanya admin@nuur.com) ─────────────
class AdminPanelPage extends StatefulWidget {
  const AdminPanelPage({super.key});
  @override
  State<AdminPanelPage> createState() => _AdminPanelPageState();
}

class _AdminPanelPageState extends State<AdminPanelPage> {
  final nameCtl = TextEditingController(text: kAiName);
  bool busy = false, nameLoaded = false;

  Future<void> _changePhoto() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85, maxWidth: 1024);
    if (x == null) return;
    setState(() => busy = true);
    try {
      final ref = FirebaseStorage.instance.ref('ai_profile/ai_avatar.jpg');
      await ref.putFile(File(x.path), SettableMetadata(contentType: 'image/jpeg'));
      final url = await ref.getDownloadURL();
      // ?v=timestamp agar cache gambar lama tidak dipakai (path storage selalu sama)
      final ver = DateTime.now().millisecondsSinceEpoch;
      await db.ref('app_config/nuur_ai').update({
        'photoUrl': url.contains('?') ? '$url&v=$ver' : '$url?v=$ver',
        'name': kAiName,
        'updatedAt': ServerValue.timestamp,
      });
      if (mounted) toast(context, 'Foto AI berhasil diupdate');
    } catch (e) {
      if (mounted) toast(context, 'Gagal upload: $e');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _saveName() async {
    final n = nameCtl.text.trim();
    if (n.isEmpty) return;
    await db.ref('app_config/nuur_ai').update({'name': n, 'updatedAt': ServerValue.timestamp});
    if (mounted) toast(context, 'Nama AI disimpan');
  }

  Widget _section(String t) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
      child: Text(t, style: const TextStyle(color: kGrey, fontWeight: FontWeight.w700, letterSpacing: 1)));

  @override
  Widget build(BuildContext context) {
    if (!isAdminUser) return Scaffold(appBar: mkBar(text: 'Admin Panel'), body: const Center(child: Text('Akses ditolak')));
    return Scaffold(
      appBar: mkBar(text: 'Admin Panel'),
      body: ListView(children: [
        _section('NUUR AI SETTINGS'),
        StreamBuilder<DatabaseEvent>(
          stream: db.ref('app_config/nuur_ai').onValue,
          builder: (c, sn) {
            final cfg = asMap(sn.data?.snapshot.value);
            if (!nameLoaded && cfg.isNotEmpty) { nameCtl.text = s(cfg['name']).isEmpty ? kAiName : s(cfg['name']); nameLoaded = true; }
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 16), padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(14)),
              child: Column(children: [
                const AiAvatar(r: 40),
                const SizedBox(height: 10),
                NameRow(name: s(cfg['name']).isEmpty ? kAiName : s(cfg['name']), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(cfg['enabled'] == false ? 'Maintenance' : 'Online', style: const TextStyle(color: kGrey)),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: whiteBtn(), onPressed: busy ? null : _changePhoto,
                    icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : const Icon(Icons.photo_camera_outlined, color: Colors.black),
                    label: const Text('Ganti Foto Profile AI'),
                  ),
                ),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(child: TextField(controller: nameCtl, style: const TextStyle(color: Colors.white), decoration: inputDec('Nama AI'))),
                  const SizedBox(width: 8),
                  ElevatedButton(style: whiteBtn(), onPressed: _saveName, child: const Text('Simpan')),
                ]),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero, title: const Text('Aktifkan NUUR AI'),
                  value: cfg['enabled'] != false, onChanged: (v) => db.ref('app_config/nuur_ai/enabled').set(v),
                ),
              ]),
            );
          },
        ),
        _section('PENGGUNA (BAN / UNBAN)'),
        UsersBuilder(builder: (c, users) {
          final list = users.values.where((u) => u['uid'] != myUid).toList()
            ..sort((a, b) => s(a['name']).toLowerCase().compareTo(s(b['name']).toLowerCase()));
          return Column(children: list.map((u) {
            final banned = u['isBanned'] == true;
            return ListTile(
              leading: Avatar(name: s(u['name']), r: 20),
              title: NameRow(name: s(u['name']), verified: u['isVerified'] == true),
              subtitle: Text(s(u['email']), style: const TextStyle(color: kGrey, fontSize: 12)),
              trailing: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: banned ? Colors.white : Colors.redAccent, foregroundColor: banned ? Colors.black : Colors.white),
                onPressed: () => db.ref('users/${s(u['uid'])}/isBanned').set(!banned),
                child: Text(banned ? 'UNBAN' : 'BAN'),
              ),
            );
          }).toList());
        }),
        const SizedBox(height: 30),
      ]),
    );
  }
}
